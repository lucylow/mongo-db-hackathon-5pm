import { useEffect, useRef, type ReactNode } from "react";
import {
  ClerkProvider,
  Show,
  SignIn,
  SignUp,
  useClerk,
} from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import {
  AppShell,
  DashboardPage,
  DemoDataStudioPage,
  EvaluationsPage,
  GovernancePage,
  HandoversPage,
  IncidentsPage,
  InventoryPage,
  LandingPage,
  MaintenancePage,
  MemoriesPage,
  MemoryPassportPage,
  ReplaysPage,
  SettingsPage,
  SupervisorPage,
} from "@/pages/contextpilot";
import {
  Redirect,
  Route,
  Switch,
  useLocation,
  useParams,
  Router as WouterRouter,
} from "wouter";

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY in .env file");
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, refetchOnWindowFocus: false, staleTime: 15_000 },
  },
});

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "#4958c8",
    colorForeground: "#24344d",
    colorMutedForeground: "#78869a",
    colorDanger: "#b9665d",
    colorBackground: "#ffffff",
    colorInput: "#ffffff",
    colorInputForeground: "#33445c",
    colorNeutral: "#53647a",
    fontFamily: "DM Sans, sans-serif",
    borderRadius: "8px",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-white rounded-xl w-[440px] max-w-full overflow-hidden",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: { color: "#24344d", fontFamily: "Manrope, sans-serif" },
    headerSubtitle: { color: "#78869a" },
    socialButtonsBlockButtonText: { color: "#43536b", fontWeight: 600 },
    formFieldLabel: { color: "#53647a", fontWeight: 600 },
    footerActionLink: { color: "#4958c8", fontWeight: 600 },
    footerActionText: { color: "#78869a" },
    dividerText: { color: "#78869a" },
    identityPreviewEditButton: { color: "#4958c8" },
    formFieldSuccessText: { color: "#398271" },
    alertText: { color: "#9e514a" },
    logoBox: "overflow-hidden",
    logoImage: "object-contain",
    socialButtonsBlockButton: "border-[#dce2eb] bg-white hover:bg-[#f8f9fb]",
    formButtonPrimary: "bg-[#4958c8] hover:bg-[#3949b7] text-white",
    formFieldInput: "border-[#dce2eb] bg-white text-[#33445c]",
    footerAction: "bg-transparent",
    dividerLine: "bg-[#e5e9ef]",
    alert: "border-[#f0d9d5] bg-[#fff8f6]",
    otpCodeFieldInput: "border-[#dce2eb] bg-white text-[#33445c]",
    formFieldRow: "text-[#53647a]",
    main: "bg-white",
  },
};

function SignInPage() {
  return (
    <div className="clerk-auth-page">
      <div className="auth-side">
        <div className="eyebrow"><span className="eyebrow-line" /> CONTEXTPILOT / RETAIL OPERATIONS</div>
        <h1>Good decisions<br /><em>start with context.</em></h1>
        <p>Sign in to your operations workspace to review approved memories, follow evidence, and keep every store in sync.</p>
      </div>
      <div className="auth-form-frame">
        <SignIn
          routing="path"
          path={`${basePath}/sign-in`}
          signUpUrl={`${basePath}/sign-up`}
        />
      </div>
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="clerk-auth-page">
      <div className="auth-side">
        <div className="eyebrow"><span className="eyebrow-line" /> A CLEARER WAY TO RUN RETAIL</div>
        <h1>Bring every shift<br /><em>into the picture.</em></h1>
        <p>Create your ContextPilot workspace account. Your team's operational context stays governed, scoped, and traceable.</p>
      </div>
      <div className="auth-form-frame">
        <SignUp
          routing="path"
          path={`${basePath}/sign-up`}
          signInUrl={`${basePath}/sign-in`}
        />
      </div>
    </div>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        previousUserId.current !== undefined &&
        previousUserId.current !== userId
      ) {
        client.clear();
      }
      previousUserId.current = userId;
    });
    return unsubscribe;
  }, [addListener, client]);

  return null;
}

function HomePage() {
  return (
    <>
      <Show when="signed-in">
        <AppShell><DashboardPage /></AppShell>
      </Show>
      <Show when="signed-out"><LandingPage /></Show>
    </>
  );
}

function MemoryPassportRoute() {
  const { memoryId } = useParams<{ memoryId: string }>();
  return <MemoryPassportPage memoryId={memoryId} />;
}

function ReplayDetailRoute() {
  const { replayId } = useParams<{ replayId: string }>();
  return <ReplaysPage replayId={replayId} />;
}

function ReplayListRoute() {
  return <ReplaysPage />;
}

function ProtectedRouter() {
  return (
    <>
      <Show when="signed-in">
        <AppShell>
          <RoutedErrorBoundary>
            <Switch>
              <Route path="/supervisor" component={SupervisorPage} />
              <Route path="/memories" component={MemoriesPage} />
              <Route path="/memories/:memoryId" component={MemoryPassportRoute} />
              <Route path="/governance" component={GovernancePage} />
              <Route path="/replays" component={ReplayListRoute} />
              <Route path="/replays/:replayId" component={ReplayDetailRoute} />
              <Route path="/incidents" component={IncidentsPage} />
              <Route path="/handovers" component={HandoversPage} />
              <Route path="/inventory" component={InventoryPage} />
              <Route path="/maintenance" component={MaintenancePage} />
              <Route path="/evaluations" component={EvaluationsPage} />
              <Route path="/demo-data" component={DemoDataStudioPage} />
              <Route path="/settings" component={SettingsPage} />
              <Route component={NotFound} />
            </Switch>
          </RoutedErrorBoundary>
        </AppShell>
      </Show>
      <Show when="signed-out"><Redirect to="/" /></Show>
    </>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Welcome back",
            subtitle: "Sign in to your operations workspace",
          },
        },
        signUp: {
          start: {
            title: "Create your account",
            subtitle: "Get started with ContextPilot",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <ClerkQueryClientCacheInvalidator />
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route component={ProtectedRouter} />
      </Switch>
    </ClerkProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={basePath}>
          <ClerkProviderWithRoutes />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
