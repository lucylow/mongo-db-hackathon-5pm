import { useState, type FormEvent, type ReactNode } from "react";
import { useClerk } from "@clerk/react";
import { Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  Activity, ArrowDownRight, ArrowLeft, ArrowRight, ArrowUpRight, BookOpen,
  Building2, Check, CheckCircle2, ChevronDown, ChevronRight, CircleHelp,
  ClipboardCheck, Clock3, Database, FileClock, FileText, Filter, Gauge,
  HardHat, Layers3, Menu, MessageSquareText, PackageSearch, Search,
  Shield, ShieldCheck, Sparkles, Store, Thermometer, Users, Wrench,
  X, AlertTriangle, CircleDot, History, RefreshCw, Send, ExternalLink, LogOut,
} from "lucide-react";
import {
  useGetContextPilotSession, useSelectDemoPrincipal, useGetOperationsDashboard,
  useAskOperationsSupervisor, useListMemories, useGetMemoryPassport,
  useListGovernanceCandidates, useDecideGovernanceCandidate, useListMemoryReplays,
  useGetMemoryReplay, useListIncidents, useListShiftHandovers, useListInventoryEvents,
  useListMaintenanceRecords, useGetEvaluationDashboard, useGetAccessSettings,
  useGetDemoDataStudio, useGenerateDemoData, useResetDemoDataStudio,
  useHealthCheck, getGetContextPilotSessionQueryKey, getGetOperationsDashboardQueryKey,
  getListMemoriesQueryKey, getGetMemoryPassportQueryKey, getListGovernanceCandidatesQueryKey,
  getListMemoryReplaysQueryKey, getGetMemoryReplayQueryKey, getListIncidentsQueryKey,
  getListShiftHandoversQueryKey, getListInventoryEventsQueryKey, getListMaintenanceRecordsQueryKey,
  getGetEvaluationDashboardQueryKey, getGetAccessSettingsQueryKey, getGetDemoDataStudioQueryKey,
} from "@workspace/api-client-react";
import type {
  AccessSettings, AssistantAnswer, DemoDataGenerateInput, DemoDataGenerationResult,
  DemoDataResetResult, EvaluationDashboard, GovernanceCandidate,
  Incident, InventoryEvent, MaintenanceRecord, MemoryPassport, ReplayDetail,
  ReplaySummary, ShiftHandover,
} from "@workspace/api-client-react";

const navGroups = [
  { label: "OPERATIONS", items: [
    { href: "/", label: "Command centre", icon: Gauge },
    { href: "/supervisor", label: "AI supervisor", icon: MessageSquareText },
    { href: "/incidents", label: "Incident intelligence", icon: AlertTriangle },
    { href: "/handovers", label: "Shift handover", icon: FileClock },
    { href: "/inventory", label: "Inventory", icon: PackageSearch },
    { href: "/maintenance", label: "Maintenance", icon: Wrench },
  ]},
  { label: "KNOWLEDGE & CONTROL", items: [
    { href: "/memories", label: "Memory vault", icon: Database },
    { href: "/governance", label: "Review queue", icon: ClipboardCheck },
    { href: "/replays", label: "Memory replays", icon: History },
    { href: "/evaluations", label: "Evaluations", icon: Activity },
    { href: "/demo-data", label: "Demo Data Studio", icon: Layers3 },
    { href: "/settings", label: "Access management", icon: Shield },
  ]},
];

export function AppShell({ children }: { children: ReactNode }) {
  const [loc, setLoc] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { data: session } = useGetContextPilotSession();
  const selectPrincipal = useSelectDemoPrincipal();
  const queryClient = useQueryClient();
  const status = useHealthCheck();
  const [switchOpen, setSwitchOpen] = useState(false);
  const { signOut } = useClerk();
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
  const principal = session?.principal;
  const chooseDemo = (principalId: string) => {
    selectPrincipal.mutate({ data: { principalId } }, {
      onSuccess: async () => {
        await Promise.all([
          queryClient.invalidateQueries({ queryKey: getGetContextPilotSessionQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getGetOperationsDashboardQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getListMemoriesQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getListGovernanceCandidatesQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getListMemoryReplaysQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getListIncidentsQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getListShiftHandoversQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getListInventoryEventsQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getListMaintenanceRecordsQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getGetEvaluationDashboardQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getGetAccessSettingsQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getGetDemoDataStudioQueryKey() }),
          queryClient.invalidateQueries(),
        ]);
        setSwitchOpen(false);
      },
    });
  };
  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
      <Link href="/" className="brand" onClick={() => setMobileOpen(false)}>
        <span className="brand-mark"><span /><span /><span /></span>
        <span className="brand-copy"><b>ContextPilot</b><small>RETAIL OPERATIONS</small></span>
      </Link>
      <div className="tenant-pill"><span className="tenant-icon"><Store size={15}/></span><span><b>{principal?.tenantName || "Loading tenant scope"}</b><small>{principal?.storeName || "All assigned stores"}</small></span><ChevronDown size={14}/></div>
      <nav className="side-nav" aria-label="Primary navigation">
        {navGroups.map(group => <div className="nav-group" key={group.label}>
          <div className="nav-label">{group.label}</div>
          {group.items.filter(item => item.href !== "/demo-data" || session?.permissions?.includes("memory:review")).map(item => <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)} className={`nav-link ${loc === item.href ? "active" : ""}`} data-testid={`nav-${item.label.toLowerCase().replaceAll(" ","-")}`}>
            <item.icon size={17} strokeWidth={1.8}/><span>{item.label}</span>
            {item.href === "/governance" && <span className="nav-dot"/>}
          </Link>)}
        </div>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="connection"><span className={`pulse ${status.isError ? "offline" : ""}`}/><span>{status.isError ? "API unavailable" : "Systems operational"}</span><span className="connection-mode">{session?.mode || "demo"}</span></div>
        <div className="sidebar-profile"><div className="avatar">{principal?.displayName?.split(" ").map(x => x[0]).join("").slice(0,2) || "HM"}</div><div className="profile-info"><b>{principal?.displayName || "Demo operator"}</b><small>{roleLabel(principal?.role)}</small></div>
          {session?.mode === "demo" && session.demoPrincipals?.length > 1 && <button className="icon-button profile-switch" title="Switch fictional demo persona" aria-label="Switch fictional demo persona" onClick={() => setSwitchOpen(!switchOpen)} data-testid="button-switch-persona"><ChevronDown size={15}/></button>}
        </div>
        {switchOpen && <div className="persona-menu"><div className="persona-menu-note">FICTIONAL DEMO PERSONAS</div>{session?.demoPrincipals.map(person => <button key={person.id} onClick={() => chooseDemo(person.id)} disabled={selectPrincipal.isPending} className="persona-option" data-testid={`persona-${person.id}`}><span className="avatar mini">{person.displayName.split(" ").map(x=>x[0]).join("").slice(0,2)}</span><span><b>{person.displayName}</b><small>{person.tenantName} · {roleLabel(person.role)}</small></span>{principal?.id === person.id && <Check size={14}/>}</button>)}</div>}
        <button className="sign-out-button" onClick={() => signOut({ redirectUrl: basePath || "/" })} data-testid="button-sign-out"><LogOut size={14}/> Sign out</button>
      </div>
    </aside>
    {mobileOpen && <button className="mobile-scrim" aria-label="Close menu" onClick={() => setMobileOpen(false)}/>}
    <main className="main-area">
      <header className="topbar">
        <button className="icon-button mobile-menu" aria-label="Open navigation" onClick={() => setMobileOpen(true)}><Menu size={20}/></button>
        <div className="breadcrumbs"><span>{principal?.tenantName || "Retail operations"}</span><ChevronRight size={14}/><b>{pageName(loc)}</b></div>
        <div className="top-actions"><span className={`live-status ${status.isError?"offline":""}`}><i className={status.isError?"offline":""}/>{status.isLoading?"CHECKING API":status.isError?"API UNAVAILABLE":session?.mode==="atlas"?"ATLAS CONNECTED":"DEMO DATA"}</span><span className="mode-chip">{session?.mode || "…"}</span><span className="icon-button help-button" title="ContextPilot operations platform"><CircleHelp size={18}/></span><div className="top-avatar">{principal?.displayName?.split(" ").map(x=>x[0]).join("").slice(0,2) || "CP"}</div></div>
      </header>
      <div className="page-area">{children}</div>
    </main>
  </div>;
}

const pageName = (path: string) => {
  const matched = navGroups.flatMap(g=>g.items).find(x=>x.href === path);
  if (matched) return matched.label;
  if (path.startsWith("/memories/")) return "Memory passport";
  if (path.startsWith("/replays/")) return "Memory replay";
  return "Operations";
};
const roleLabel = (role?: string) => role?.replaceAll("_", " ") || "Operations";

type DemoDatasetKey = DemoDataGenerateInput["dataset"];

export function LandingPage() {
  const [, setLoc] = useLocation();
  const goDemo = () => setLoc("/sign-up");
  return <div className="landing">
      <header className="landing-header"><Link href="/" className="brand landing-brand"><span className="brand-mark"><span/><span/><span/></span><span className="brand-copy"><b>ContextPilot</b><small>RETAIL OPERATIONS</small></span></Link><div className="landing-links"><a href="#governance">Governance</a><a href="#workflow">How it works</a><Link href="/sign-in" className="button button-quiet">Sign in <ArrowRight size={15}/></Link><Link href="/sign-up" className="button button-primary">Create account</Link></div></header>
    <section className="landing-hero">
      <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-line"/> OPERATIONS, WITH CONTEXT</div><h1>Every answer.<br/><em>Accounted for.</em></h1><p className="hero-lede">A governed AI supervisor for the people who keep grocery stores moving. Trace every memory to its source, reviewer, and effect on the next decision.</p>
        <div className="hero-cta"><button className="button button-primary button-large" onClick={goDemo} data-testid="button-enter-demo">Create your workspace <ArrowRight size={16}/></button><Link href="/sign-in" className="button button-outline button-large">Sign in to your workspace</Link></div>
        <div className="hero-proof"><span><ShieldCheck size={16}/> Evidence-linked answers</span><span><CheckCircle2 size={16}/> Human-approved knowledge</span></div>
      </div>
      <div className="hero-visual">
        <div className="visual-grid"/>
        <div className="hero-console">
          <div className="console-head"><span className="console-status"><i/> SUPERVISOR RUN</span><span className="mono">RUN · 8F3A-014</span></div>
          <div className="console-question"><small>QUESTION · STORE 014</small><b>What happened with cooler C-14, and what should I do now?</b></div>
          <div className="console-answer"><div className="answer-line"><span className="answer-check"><Check size={12}/></span><p>Compressor overload on Feb 18. The unit is stable after the relay replacement, but airflow checks are required at open.</p></div>
            <div className="citation-card"><span className="citation-number">01</span><span><b>Cooler C-14 · recovery procedure</b><small>Memory v3 · approved by L. Chen</small></span><ArrowUpRight size={14}/></div>
          </div>
          <div className="console-foot"><span><ShieldCheck size={14}/> 3 policy checks passed</span><span className="mono">SOURCES 2</span></div>
        </div>
        <div className="visual-note"><span className="note-mark"><Check size={13}/></span><span><b>Reviewed knowledge</b><small>Never an untraceable answer</small></span></div>
        <div className="hero-index">01 <span>/</span> GOVERNED MEMORY</div>
      </div>
      <div className="hero-bottomline"><span>BUILT FOR MULTI-LOCATION GROCERY</span><span>STORE TEAMS · KNOWLEDGE STEWARDS · OPERATIONS LEADERS</span></div>
    </section>
    <section className="landing-section workflow-section" id="workflow"><div className="section-intro"><div className="eyebrow"><span className="eyebrow-line"/> OPERATIONAL MEMORY</div><h2>Not just what AI knows.<br/><em>Why it knows it.</em></h2><p>ContextPilot puts the full knowledge lifecycle in view: provenance, approval, policy, and the measurable change a correction makes.</p></div>
      <div className="workflow-track">
        <div className="workflow-step"><span className="step-number">01</span><div className="step-icon"><FileText size={21}/></div><h3>Evidence enters</h3><p>Store logs, equipment notes, and team observations become traceable candidates.</p><span className="step-rule"/></div>
        <div className="workflow-step"><span className="step-number">02</span><div className="step-icon"><Users size={21}/></div><h3>A steward reviews</h3><p>Authorized people correct, approve, reject, or request stronger evidence.</p><span className="step-rule"/></div>
        <div className="workflow-step"><span className="step-number">03</span><div className="step-icon"><MessageSquareText size={21}/></div><h3>Answers cite memory</h3><p>Store teams get grounded guidance with visible citations and policy decisions.</p><span className="step-rule"/></div>
        <div className="workflow-step"><span className="step-number">04</span><div className="step-icon"><History size={21}/></div><h3>Impact is replayed</h3><p>Compare saved runs to see exactly how approved corrections change an answer.</p></div>
      </div>
    </section>
    <section className="landing-feature" id="governance"><div className="feature-art"><div className="feature-art-top"><span>MEMORY PASSPORT</span><span className="tag tag-approved">APPROVED</span></div><div className="feature-art-title">Cooler C-14<br/>recovery procedure</div><div className="feature-art-meta"><span>AUTHOR</span><b>Maintenance log · S. Patel</b><span>REVIEWER</span><b>L. Chen · Knowledge steward</b><span>VERSION</span><b>03 · effective Feb 21</b></div><div className="feature-art-timeline"><i/><i/><i/><i/></div><div className="feature-art-labels"><span>CAPTURED</span><span>REVIEWED</span><span>CORRECTED</span><span>ACTIVE</span></div></div>
      <div className="feature-copy"><div className="eyebrow"><span className="eyebrow-line"/> ACCOUNTABLE BY DESIGN</div><h2>Institutional knowledge,<br/><em>with a paper trail.</em></h2><p>Every durable procedure is attached to its source, reviewer, version, sensitivity, and review date. No one needs to guess what the system remembers—or who said it was safe to use.</p><ul className="feature-list"><li><Check size={15}/> Source-level provenance and hash</li><li><Check size={15}/> Reviewer and effective-date visibility</li><li><Check size={15}/> Version history that never disappears</li></ul><Link href="/memories" className="text-link">Explore the memory vault <ArrowRight size={15}/></Link></div></section>
    <section className="landing-last"><div><div className="eyebrow"><span className="eyebrow-line"/> A BETTER SHIFT STARTS HERE</div><h2>Make every answer<br/><em>operationally useful.</em></h2></div><button className="button button-light button-large" onClick={goDemo}>Create a workspace <ArrowRight size={16}/></button><span className="last-orbit orbit-one"/><span className="last-orbit orbit-two"/></section>
    <footer className="landing-footer"><Link href="/" className="brand"><span className="brand-mark"><span/><span/><span/></span><span className="brand-copy"><b>ContextPilot</b><small>RETAIL OPERATIONS</small></span></Link><span>GOVERNED CONTEXT FOR THE FRONT LINE</span><span>© 2025 CONTEXTPILOT</span></footer>
  </div>;
}

export function DashboardPage() {
  const { data, isLoading, isError, refetch } = useGetOperationsDashboard();
  const { data: memories } = useListMemories(undefined);
  const { data: candidates } = useListGovernanceCandidates();
  if (isLoading) return <LoadingPage title="Command centre"/>;
  if (isError || !data) return <ErrorState onRetry={() => refetch()} title="Dashboard unavailable"/>;
  return <PageHeader eyebrow="STORE OPERATIONS / OVERVIEW" title="Command centre" description={`${data.storeName} · ${data.tenantName}`} action={<Link href="/supervisor" className="button button-primary"><Sparkles size={15}/> Ask the supervisor</Link>}>
    <div className="metric-grid">{data.metrics.map((m,i)=><MetricCard key={m.label} label={m.label} value={m.value} change={m.change} tone={m.tone} index={i}/>)}</div>
    <div className="dashboard-grid">
      <section className="panel activity-panel"><PanelTitle eyebrow="RECENT SIGNAL" title="What needs attention" action={<Link href="/incidents" className="text-link small">All activity <ArrowRight size={14}/></Link>}/>
        {data.activity.length ? <div className="activity-list">{data.activity.map((a,i)=><div className="activity-row" key={a.id} data-testid={`activity-${a.id}`}><div className={`activity-icon activity-${a.kind}`}><Activity size={16}/></div><div className="activity-content"><b>{a.title}</b><p>{a.detail}</p><small>{relativeDate(a.createdAt)}</small></div><span className="activity-index">{String(i+1).padStart(2,"0")}</span></div>)}</div> : <EmptyState icon={<Activity size={20}/>} title="No recent activity" detail="New signals will appear here as stores report them."/>}
      </section>
      <section className="panel readiness-panel"><PanelTitle eyebrow="GOVERNANCE HEALTH" title="Knowledge readiness"/>
        <div className="readiness-score"><div className="score-ring"><span>{memories?.length ? Math.round((memories.filter(x=>x.status==="approved").length / memories.length)*100) : 0}<small>%</small></span></div><div><b>Approved knowledge</b><p>Visible, versioned, and ready for retrieval.</p></div></div>
        <div className="readiness-bars"><ReadinessBar label="Approved memories" value={memories?.filter(x=>x.status==="approved").length || 0} max={memories?.length || 1} color="indigo"/><ReadinessBar label="Awaiting review" value={candidates?.length || 0} max={Math.max(candidates?.length || 0,8)} color="teal"/></div>
        <div className="readiness-footer"><span><ShieldCheck size={15}/> Policy controls active</span><Link href="/governance">Review queue <ArrowRight size={14}/></Link></div>
      </section>
    </div>
    <section className="panel store-panel"><PanelTitle eyebrow="LOCATION NETWORK" title="Store pulse" action={<span className="subtle-label"><span className="pulse"/> {data.stores.length} STORES IN VIEW</span>}/>
      <div className="table-wrap"><table><thead><tr><th>STORE</th><th>STATUS</th><th>OPEN INCIDENTS</th><th>MAINTENANCE</th><th>HEALTH</th></tr></thead><tbody>{data.stores.map((s,i)=><tr key={s.storeId}><td><div className="store-cell"><span className="store-seq">{String(i+1).padStart(2,"0")}</span><b>{s.storeName}</b><small>{s.storeId}</small></div></td><td><StatusTag value={s.status}/></td><td className="mono">{s.incidents}</td><td className="mono">{s.openMaintenance}</td><td><div className="health-track"><i style={{width:`${Math.max(20,100-s.incidents*12-s.openMaintenance*7)}%`}}/></div></td></tr>)}</tbody></table></div>
    </section>
    <div className="dashboard-lower"><Link href="/supervisor" className="shortcut-card"><span className="shortcut-symbol"><MessageSquareText size={19}/></span><div><small>START WITH A QUESTION</small><b>Ask what happened at C-14</b><p>See history, evidence, and next steps.</p></div><ArrowUpRight size={17}/></Link><Link href="/replays" className="shortcut-card"><span className="shortcut-symbol teal"><History size={19}/></span><div><small>COMPARE ANSWERS</small><b>Inspect a memory replay</b><p>Review the before-and-after impact.</p></div><ArrowUpRight size={17}/></Link></div>
  </PageHeader>;
}

export function SupervisorPage() {
  const queryClient = useQueryClient();
  const ask = useAskOperationsSupervisor();
  const [question,setQuestion] = useState("");
  const [answer,setAnswer] = useState<AssistantAnswer | null>(null);
  const [conversation,setConversation] = useState<string[]>([]);
  const [lastQuestion,setLastQuestion] = useState("");
  const submit = (e?: FormEvent) => {
    e?.preventDefault();
    const q=question.trim(); if(q.length<3 || ask.isPending) return;
    setConversation(old=>[...old,q]); setLastQuestion(q); setQuestion("");
    ask.mutate({ data:{question:q} }, { onSuccess: async result=>{
      setAnswer(result);
      await queryClient.invalidateQueries({ queryKey: getListMemoryReplaysQueryKey() });
      if (result.replayId) await queryClient.invalidateQueries({ queryKey: getGetMemoryReplayQueryKey(result.replayId) });
    }});
  };
  const quick = "What is the history of cooler C-14 at Store 014, and what should the opening team do now?";
  return <PageHeader eyebrow="CONTEXTPILOT / GROUNDED ASSISTANCE" title="Operations supervisor" description="Ask a store question. Every answer is checked against approved evidence." action={<span className="tag tag-live"><i/> GOVERNED MODE</span>}>
    <div className="supervisor-layout">
      <section className="panel conversation-panel">
        <div className="conversation-top"><div className="assistant-identity"><span className="assistant-icon"><Sparkles size={17}/></span><span><b>ContextPilot supervisor</b><small>Evidence-first operations guidance</small></span></div><span className="subtle-label"><ShieldCheck size={14}/> POLICY ACTIVE</span></div>
        <div className="conversation-body">
          {!conversation.length && !answer && <div className="welcome-state"><div className="welcome-orbit"><div className="welcome-core"><Sparkles size={22}/></div><i/><i/><i/></div><div className="eyebrow">STORE 014 · COOLER C-14</div><h2>Start with the whole story.</h2><p>Ask about a store event, procedure, or handover. ContextPilot will show what informed its response.</p><button className="suggested-question" onClick={()=>setQuestion(quick)} data-testid="button-suggested-question"><span><MessageSquareText size={15}/></span>{quick}<ArrowRight size={15}/></button></div>}
          {conversation.map((q,i)=><div className="message user-message" key={`${q}-${i}`}><div className="message-avatar">OP</div><div><small>YOU · {timeNow()}</small><p>{q}</p></div></div>)}
          {ask.isPending && <div className="message assistant-message"><div className="assistant-icon"><Sparkles size={15}/></div><div className="answer-skeleton"><i/><i/><i/></div></div>}
          {ask.isError && <div className="inline-error"><AlertTriangle size={15}/> The supervisor could not complete that answer. <button onClick={()=>ask.mutate({data:{question:lastQuestion}},{onSuccess:result=>setAnswer(result)})}>Try again</button></div>}
          {answer && <AnswerCard answer={answer}/>}
        </div>
        <form className="prompt-box" onSubmit={submit}><textarea value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Ask about a store, incident, or procedure…" rows={2} data-testid="input-supervisor-question" onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();submit()}}}/><div className="prompt-foot"><span><ShieldCheck size={13}/> Answers are scoped to your access</span><button className="button button-primary" type="submit" disabled={question.trim().length<3||ask.isPending} data-testid="button-ask-supervisor">{ask.isPending?"Checking…":"Ask supervisor"} <Send size={14}/></button></div></form>
      </section>
      <aside className="supervisor-aside">
        <section className="panel context-card"><PanelTitle eyebrow="CURRENT CONTEXT" title="Store 014"/><div className="context-equipment"><div className="equipment-icon"><Thermometer size={19}/></div><div><b>Cooler C-14</b><small>Produce · back wall</small></div><StatusTag value="Stable"/></div><div className="context-lines"><div><span>Last incident</span><b>Feb 18 · compressor overload</b></div><div><span>Current procedure</span><b>Recovery protocol · v3</b></div><div><span>Evidence sources</span><b>2 approved memories</b></div></div><Link href="/memories" className="text-link">View related memories <ArrowRight size={14}/></Link></section>
        <section className="panel trust-card"><span className="trust-icon"><ShieldCheck size={18}/></span><h3>Governed, not guessed.</h3><p>Responses use approved memories only. If evidence is missing or access is denied, the supervisor says so.</p><div className="trust-badge"><span className="pulse"/> POLICY ENGINE ACTIVE</div></section>
        <section className="panel demo-path"><div className="eyebrow">DEMO WALKTHROUGH</div><ol><li className="done"><i><Check size={11}/></i><span><b>Ask about C-14</b><small>See citations and policy checks</small></span></li><li><i>2</i><span><b>Correct the procedure</b><small>Approve as a knowledge steward</small></span></li><li><i>3</i><span><b>Ask again and replay</b><small>Compare the saved runs</small></span></li></ol><Link href="/governance" className="text-link">Open review queue <ArrowRight size={14}/></Link></section>
      </aside>
    </div>
  </PageHeader>;
}

function AnswerCard({answer}:{answer:AssistantAnswer}) {
  return <div className="answer-wrap"><div className="answer-head"><span className={`answer-status ${answer.abstained?"status-review":"status-allowed"}`}>{answer.abstained?<CircleDot size={13}/>:<CheckCircle2 size={13}/>} {answer.abstained?"ABSTAINED":"GROUNDED ANSWER"}</span><span className="mono">RUN {answer.runId.slice(0,10)}</span></div><div className="answer-copy">{answer.answer}</div>
    <div className="answer-details"><div className="detail-label"><BookOpen size={14}/> CITED MEMORIES <span>{answer.citations.length}</span></div>{answer.citations.length ? answer.citations.map(c=><Link key={`${c.memoryId}-${c.version}`} href={`/memories/${c.memoryId}`} className="citation-row"><span className="citation-n">{String(c.version).padStart(2,"0")}</span><span><b>{c.title}</b><small>{c.excerpt}</small></span><ArrowUpRight size={14}/></Link>) : <p className="empty-inline">No approved memory was cited.</p>}</div>
    <div className="policy-strip"><div className="detail-label"><ShieldCheck size={14}/> POLICY DECISIONS</div><div className="policy-chips">{answer.policyDecisions.map((p,i)=><span className={`policy-chip ${p.decision.toLowerCase()}`} key={`${p.decision}-${i}`}><i/>{p.decision}<small>{p.reason}</small></span>)}</div></div>
    <div className="answer-foot"><span>{answer.provider} · {relativeDate(answer.generatedAt)}</span>{answer.replayId&&<Link href={`/replays/${answer.replayId}`} className="text-link small">Compare this run <ArrowRight size={13}/></Link>}</div>
  </div>;
}

export function MemoriesPage() {
  const [search,setSearch]=useState("");
  const [status,setStatus]=useState("");
  const {data,isLoading,isError,refetch}=useListMemories({search:search||undefined,status:status||undefined});
  if(isLoading)return <LoadingPage title="Memory vault"/>;
  if(isError)return <ErrorState title="Memory vault unavailable" onRetry={()=>refetch()}/>;
  const memories=data||[];
  return <PageHeader eyebrow="GOVERNED KNOWLEDGE / MEMORY VAULT" title="Memory vault" description="Every approved fact with its lifecycle, provenance, and scope." action={<span className="data-count"><Database size={15}/>{memories.length} MEMORIES</span>}>
    <section className="panel table-panel"><div className="table-toolbar"><div className="search-box"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search memories…" data-testid="input-memory-search"/></div><label className="select-box"><Filter size={15}/><select value={status} onChange={e=>setStatus(e.target.value)} data-testid="select-memory-status"><option value="">All statuses</option><option value="approved">Approved</option><option value="candidate">Candidate</option><option value="superseded">Superseded</option><option value="expired">Expired</option><option value="rejected">Rejected</option></select><ChevronDown size={14}/></label></div>
      {memories.length?<div className="table-wrap"><table><thead><tr><th>MEMORY</th><th>TYPE</th><th>STATUS</th><th>VERSION</th><th>CONFIDENCE</th><th>UPDATED</th><th/></tr></thead><tbody>{memories.map(m=><tr key={m.id} data-testid={`row-memory-${m.id}`}><td><Link href={`/memories/${m.id}`} className="table-primary-link"><b>{m.title}</b><small>{m.text}</small></Link></td><td><span className="category-label">{m.category}</span></td><td><StatusTag value={m.status}/></td><td className="mono">v{m.version}</td><td><Confidence value={m.confidence}/></td><td>{relativeDate(m.updatedAt)}</td><td><Link href={`/memories/${m.id}`} className="row-open" aria-label={`Open ${m.title}`}><ArrowUpRight size={15}/></Link></td></tr>)}</tbody></table></div>:<EmptyState icon={<Database size={21}/>} title={search?"No matching memories":"Memory vault is empty"} detail="Try another search or clear the status filter." action={status||search?<button className="button button-outline" onClick={()=>{setSearch("");setStatus("")}}>Clear filters</button>:undefined}/>}
    </section>
    <div className="footnote-row"><span><ShieldCheck size={14}/> Only memories in your tenant and store scope are shown.</span><Link href="/governance">Review candidate memories <ArrowRight size={14}/></Link></div>
  </PageHeader>;
}

export function MemoryPassportPage({ memoryId }: {memoryId:string}) {
  const {data,isLoading,isError,refetch}=useGetMemoryPassport(memoryId,{query:{queryKey:getGetMemoryPassportQueryKey(memoryId)}});
  if(isLoading)return <LoadingPage title="Memory passport"/>;
  if(isError||!data)return <ErrorState title="Memory passport unavailable" onRetry={()=>refetch()}/>;
  const memory=data as MemoryPassport;
  return <PageHeader eyebrow="MEMORY VAULT / PASSPORT" title={memory.title} description={`${memory.category} · ${memory.type}`} action={<><StatusTag value={memory.status}/><Link href="/memories" className="button button-outline"><ArrowLeft size={14}/> Back to vault</Link></>}>
    <div className="passport-grid"><div className="passport-main">
      <section className="panel passport-content"><div className="passport-content-head"><div><div className="eyebrow">CURRENT APPROVED PROCEDURE</div><span className="version-pill">VERSION {memory.version}</span></div><Confidence value={memory.confidence}/></div><p className="passport-text">{memory.text}</p><div className="passport-context"><span><Store size={14}/> {memory.storeId||"Tenant-wide"}</span><span><Clock3 size={14}/> Effective {formatDate(memory.effectiveAt)}</span><span><Shield size={14}/> {memory.sensitivity}</span></div></section>
      <section className="panel"><PanelTitle eyebrow="IMMUTABLE HISTORY" title="Version timeline"/>{memory.versions?.length?<div className="version-timeline">{memory.versions.map((v,i)=><div className={`timeline-item ${i===0?"current":""}`} key={`${v.version}-${v.createdAt}`}><span className="timeline-node"/><div className="timeline-meta"><b>Version {v.version}</b><StatusTag value={v.status}/><span>{formatDate(v.createdAt)}</span></div><p>{v.text}</p><div className="timeline-byline">Authored by {v.author}{v.reviewer?` · reviewed by ${v.reviewer}`:""}</div></div>)}</div>:<EmptyState title="No version history" detail="There are no earlier versions recorded."/>}</section>
      <section className="panel"><PanelTitle eyebrow="LIFECYCLE" title="Review events"/>{memory.events?.length?<div className="event-list">{memory.events.map((ev,i)=><div className="event-row" key={ev.id}><div className="event-marker">{i===0?<Check size={13}/>:<CircleDot size={13}/>}</div><div><div className="event-heading"><b>{ev.action.replaceAll("_"," ")}</b><span>{relativeDate(ev.createdAt)}</span></div><p>{ev.detail}</p><small>{ev.actor}</small></div></div>)}</div>:<EmptyState title="No lifecycle events" detail="Events will appear as this memory changes."/>}</section>
    </div><aside className="passport-side">
      <section className="panel passport-facts"><PanelTitle eyebrow="SOURCE & STEWARDSHIP" title="Provenance"/><Fact label="AUTHOR" value={memory.author}/><Fact label="REVIEWER" value={memory.reviewer||"Not recorded"}/><Fact label="VERIFICATION" value={memory.verificationStatus} marker/><Fact label="SOURCE REVISION" value={memory.sourceRevision||"—"} mono/><Fact label="SOURCE HASH" value={memory.sourceHash||"—"} mono/><Fact label="REVIEW DUE" value={memory.reviewAt?formatDate(memory.reviewAt):"No scheduled review"}/></section>
      <section className="panel source-box"><div className="source-box-icon"><FileText size={17}/></div><div><b>{memory.sourceIds?.length||0} linked sources</b><p>Evidence that informed this memory is preserved alongside each version.</p></div>{memory.sourceIds?.map(id=><span className="source-id" key={id}>{id}</span>)}</section>
      <Link href="/replays" className="shortcut-card compact-shortcut"><span className="shortcut-symbol teal"><History size={18}/></span><div><small>MEMORY IMPACT</small><b>See what changed</b></div><ArrowRight size={15}/></Link>
    </aside></div>
  </PageHeader>;
}

export function GovernancePage() {
  const {data,isLoading,isError,refetch}=useListGovernanceCandidates();
  const queryClient=useQueryClient();
  const decision=useDecideGovernanceCandidate();
  const [editing,setEditing]=useState<GovernanceCandidate|null>(null);
  const [corrected,setCorrected]=useState("");
  const [note,setNote]=useState("");
  const [message,setMessage]=useState("");
  const candidates=data||[];
  const decide=(candidate:GovernanceCandidate,action:"approve"|"reject"|"request_evidence"|"correct")=>{
    if(action==="correct"&&!corrected.trim())return;
    decision.mutate({candidateId:candidate.id,data:{action,...(action==="correct"?{correctedText:corrected.trim(),note:note||undefined}:{}),...(action==="request_evidence"?{note:note||"Please attach source evidence."}:{})}},{
      onSuccess:async result=>{
        await Promise.all([
          queryClient.invalidateQueries({queryKey:getListGovernanceCandidatesQueryKey()}),
          queryClient.invalidateQueries({queryKey:getListMemoriesQueryKey()}),
          queryClient.invalidateQueries({queryKey:getGetOperationsDashboardQueryKey()}),
          queryClient.invalidateQueries({queryKey:getListMemoryReplaysQueryKey()}),
          result.memoryId?queryClient.invalidateQueries({queryKey:getGetMemoryPassportQueryKey(result.memoryId)}):Promise.resolve(),
        ]);
        setEditing(null);setCorrected("");setNote("");setMessage(`Candidate ${action==="correct"?"corrected and submitted":action==="approve"?"approved":action==="reject"?"rejected":"returned for evidence"}.`);
      },
    });
  };
  if(isLoading)return <LoadingPage title="Review queue"/>;
  if(isError)return <ErrorState title="Review queue unavailable" onRetry={()=>refetch()}/>;
  return <PageHeader eyebrow="GOVERNED KNOWLEDGE / STEWARDSHIP" title="Review queue" description="Inspect evidence and decide what becomes durable operational memory." action={<span className="tag tag-review"><i/>{candidates.length} AWAITING REVIEW</span>}>
    {message&&<div className="success-banner"><CheckCircle2 size={16}/>{message}<button onClick={()=>setMessage("")}><X size={14}/></button></div>}
    {candidates.length?<div className="review-grid">{candidates.map(c=><article className="panel candidate-card" key={c.id} data-testid={`candidate-${c.id}`}><div className="candidate-top"><span className="eyebrow">CANDIDATE · {c.storeId}</span><span className="confidence-chip">{Math.round(c.confidence*100)}% confidence</span></div><h2>{c.title}</h2><p className="candidate-proposed">{c.proposedText}</p><div className="source-excerpt"><div className="excerpt-label"><FileText size={13}/> SOURCE EXCERPT</div><p>“{c.sourceExcerpt}”</p><small>Recorded by {c.sourceAuthor} · {relativeDate(c.createdAt)}</small></div>
        {(c.possibleContradictions.length>0||c.possibleDuplicates.length>0)&&<div className="candidate-flags">{c.possibleContradictions.length>0&&<span className="flag warning"><AlertTriangle size={13}/>{c.possibleContradictions.length} possible contradictions</span>}{c.possibleDuplicates.length>0&&<span className="flag"><Layers3 size={13}/>{c.possibleDuplicates.length} similar memories</span>}</div>}
        <div className="candidate-meta"><span><Building2 size={14}/>{c.tenantId}</span><span><Clock3 size={14}/>Suggested expiry {formatDate(c.suggestedExpiry)}</span></div>
        {editing?.id===c.id&&<div className="correction-form"><label>Corrected procedure<textarea value={corrected} onChange={e=>setCorrected(e.target.value)} rows={4} placeholder="Write the precise procedure the team should follow…" data-testid="input-corrected-procedure"/></label><label>Steward note <input value={note} onChange={e=>setNote(e.target.value)} placeholder="Optional rationale" data-testid="input-steward-note"/></label><div className="correction-actions"><button className="button button-outline" onClick={()=>setEditing(null)}>Cancel</button><button className="button button-primary" disabled={!corrected.trim()||decision.isPending} onClick={()=>decide(c,"correct")} data-testid="button-correct-approve">{decision.isPending?"Saving…":"Correct & approve"} <Check size={14}/></button></div></div>}
        {editing?.id!==c.id&&<div className="candidate-actions"><button className="button button-outline" onClick={()=>{setEditing(c);setCorrected(c.proposedText)}} data-testid={`button-correct-${c.id}`}>Correct</button><button className="button button-quiet" onClick={()=>decide(c,"request_evidence")} disabled={decision.isPending} data-testid={`button-evidence-${c.id}`}>Request evidence</button><button className="button button-primary" onClick={()=>decide(c,"approve")} disabled={decision.isPending} data-testid={`button-approve-${c.id}`}><Check size={14}/> Approve</button><button className="reject-link" onClick={()=>decide(c,"reject")} disabled={decision.isPending} data-testid={`button-reject-${c.id}`}>Reject</button></div>}
        {decision.isError&&<div className="inline-error compact-error">Decision failed. Retry when the connection is restored.</div>}
      </article>)}</div>:<EmptyState icon={<ClipboardCheck size={23}/>} title="All caught up" detail="No knowledge candidates are waiting for review. New evidence will appear here."/>}
    <div className="governance-note"><ShieldCheck size={16}/><span><b>Human approval is required</b><small>Candidate suggestions never enter retrieval until an authorized steward approves them.</small></span></div>
  </PageHeader>;
}

export function IncidentsPage() {
  const {data,isLoading,isError,refetch}=useListIncidents();
  if(isLoading)return <LoadingPage title="Incident intelligence"/>;
  if(isError)return <ErrorState title="Incident intelligence unavailable" onRetry={()=>refetch()}/>;
  const incidents=data||[];
  return <DataListPage eyebrow="STORE OPERATIONS / SIGNALS" title="Incident intelligence" description="Cross-store incidents, equipment history, and their operational status." count={incidents.length} countLabel="INCIDENTS">
    {incidents.length?<div className="incident-grid">{incidents.map((item,i)=><IncidentCard item={item} index={i} key={item.id}/>)}</div>:<EmptyState icon={<AlertTriangle size={21}/>} title="No incidents reported" detail="Store incidents will appear here as they are recorded."/>}
  </DataListPage>;
}

export function HandoversPage() {
  const {data,isLoading,isError,refetch}=useListShiftHandovers();
  if(isLoading)return <LoadingPage title="Shift handover"/>;
  if(isError)return <ErrorState title="Shift handovers unavailable" onRetry={()=>refetch()}/>;
  const list=data||[];
  return <DataListPage eyebrow="STORE OPERATIONS / CONTINUITY" title="Shift handover" description="A clear view of what the next crew inherits—and what still needs action." count={list.length} countLabel="HANDOVERS">
    {list.length?<div className="handover-list">{list.map(h=><HandoverCard item={h} key={h.id}/>)}</div>:<EmptyState icon={<FileClock size={21}/>} title="No handovers yet" detail="Shift transitions will be listed here when available."/>}
  </DataListPage>;
}

export function InventoryPage() {
  const {data,isLoading,isError,refetch}=useListInventoryEvents();
  if(isLoading)return <LoadingPage title="Inventory intelligence"/>;
  if(isError)return <ErrorState title="Inventory events unavailable" onRetry={()=>refetch()}/>;
  const list=data||[];
  return <DataListPage eyebrow="STORE OPERATIONS / STOCK ACCURACY" title="Inventory intelligence" description="Discrepancies worth attention across stores, ranked by severity." count={list.length} countLabel="EVENTS">
    <section className="panel table-panel"><PanelTitle eyebrow="INVENTORY SIGNALS" title="Discrepancy log" action={<span className="subtle-label"><PackageSearch size={14}/> LATEST FIRST</span>}/>{list.length?<div className="table-wrap"><table><thead><tr><th>PRODUCT</th><th>SKU</th><th>STORE</th><th>DISCREPANCY</th><th>SEVERITY</th><th>STATUS</th><th>REPORTED</th></tr></thead><tbody>{list.map(ev=><tr key={ev.id}><td><b>{ev.product}</b></td><td className="mono">{ev.sku}</td><td>{ev.storeId}</td><td>{ev.discrepancy}</td><td><SeverityTag value={ev.severity}/></td><td><StatusTag value={ev.status}/></td><td>{relativeDate(ev.createdAt)}</td></tr>)}</tbody></table></div>:<EmptyState icon={<PackageSearch size={21}/>} title="No inventory discrepancies" detail="Stock exceptions will appear here when reported."/>}</section>
  </DataListPage>;
}

export function MaintenancePage() {
  const {data,isLoading,isError,refetch}=useListMaintenanceRecords();
  if(isLoading)return <LoadingPage title="Maintenance intelligence"/>;
  if(isError)return <ErrorState title="Maintenance records unavailable" onRetry={()=>refetch()}/>;
  const list=data||[];
  return <DataListPage eyebrow="STORE OPERATIONS / EQUIPMENT" title="Maintenance intelligence" description="Equipment issues and procedures available to the maintenance team." count={list.length} countLabel="RECORDS">
    {list.length?<div className="maintenance-grid">{list.map((m,i)=><MaintenanceCard key={m.id} item={m} index={i}/>)}</div>:<EmptyState icon={<Wrench size={21}/>} title="No maintenance records" detail="Open equipment issues will appear here."/>}
  </DataListPage>;
}

export function ReplaysPage({ replayId }: { replayId?:string }) {
  const queryClient=useQueryClient();
  const {data:list,isLoading,isError,refetch}=useListMemoryReplays();
  const detailQuery=useGetMemoryReplay(replayId||"",{query:{enabled:!!replayId,queryKey:getGetMemoryReplayQueryKey(replayId||"")}});
  if(isLoading)return <LoadingPage title="Memory impact replay"/>;
  if(isError)return <ErrorState title="Replay history unavailable" onRetry={()=>refetch()}/>;
  const replays=list||[];
  return <PageHeader eyebrow="GOVERNED KNOWLEDGE / IMPACT" title="Memory impact replay" description="Compare historical and current answers across a reviewed correction." action={<span className="data-count"><History size={15}/>{replays.length} SAVED RUNS</span>}>
    <div className="replay-intro"><span className="replay-mark"><History size={19}/></span><div><b>Corrections should change outcomes.</b><p>Each replay preserves both runs, their citations, retrieved memory versions, and the correction event in between.</p></div><button className="icon-button" onClick={()=>{queryClient.invalidateQueries({queryKey:getListMemoryReplaysQueryKey()})}} aria-label="Refresh replays" data-testid="button-refresh-replays"><RefreshCw size={16}/></button></div>
    {replayId&&detailQuery.isLoading?<div className="panel"><LoadingPage title="Replay detail"/></div>:replayId&&detailQuery.isError?<ErrorState title="Replay detail unavailable" onRetry={()=>detailQuery.refetch()}/>:replayId&&detailQuery.data?<ReplayCompare replay={detailQuery.data}/>:null}
    {replays.length?<section className="panel replay-list-panel"><PanelTitle eyebrow="HISTORICAL RUNS" title="Saved comparisons"/><div className="replay-list">{replays.map((item:ReplaySummary)=><Link key={item.id} href={`/replays/${item.id}`} className={`replay-row ${replayId===item.id?"selected":""}`}><span className="replay-index">{String(replays.indexOf(item)+1).padStart(2,"0")}</span><div className="replay-question"><b>{item.question}</b><small>{relativeDate(item.createdAt)} · {item.status}</small></div><div className="replay-delta"><span className="before-dot"/> Historical <ArrowRight size={12}/><span className="after-dot"/> Updated</div><ArrowUpRight size={15}/></Link>)}</div></section>:<EmptyState icon={<History size={21}/>} title="No saved replays" detail="Ask about Store 014, approve a correction, then ask again to create a comparison." action={<Link href="/supervisor" className="button button-primary">Ask the supervisor <ArrowRight size={14}/></Link>}/>}
  </PageHeader>;
}

function ReplayCompare({replay}:{replay:ReplayDetail}) {
  return <section className="panel replay-compare"><div className="compare-header"><div><div className="eyebrow">MEMORY IMPACT / RUN COMPARISON</div><h2>{replay.question}</h2></div><span className="tag tag-approved"><CheckCircle2 size={13}/> CORRECTION APPLIED</span></div>
    <div className="correction-ribbon"><span className="ribbon-check"><Check size={13}/></span><span><b>{replay.correctionEvent.action.replaceAll("_"," ")}</b><small>{replay.correctionEvent.detail} · {replay.correctionEvent.actor}</small></span><span className="ribbon-date">{relativeDate(replay.correctionEvent.createdAt)}</span></div>
    <div className="comparison-grid"><ReplaySnapshot snapshot={replay.before} label="BEFORE CORRECTION" tone="before"/><ReplaySnapshot snapshot={replay.after} label="AFTER CORRECTION" tone="after"/></div>
  </section>;
}
function ReplaySnapshot({snapshot,label,tone}:{snapshot:ReplayDetail["before"];label:string;tone:string}) {
  return <article className={`snapshot-card ${tone}`}><div className="snapshot-label"><span className={`snapshot-dot ${tone}`}/>{label}<span className="mono">{snapshot.runId.slice(0,9)}</span></div><p>{snapshot.answer}</p><div className="snapshot-sources"><small>RETRIEVED MEMORY VERSIONS</small>{snapshot.retrievedMemories.length?snapshot.retrievedMemories.map((m,i)=><div key={`${m.version}-${i}`}><BookOpen size={13}/><span>{m.text.slice(0,88)}{m.text.length>88?"…":""}</span><b>v{m.version}</b></div>):<em>No memory versions recorded</em>}</div><div className="snapshot-policy">{snapshot.policyDecisions.map((d,i)=><span key={i} className={`policy-mini ${d.decision.toLowerCase()}`}>{d.decision}</span>)}</div></article>;
}

export function EvaluationsPage() {
  const {data,isLoading,isError,refetch}=useGetEvaluationDashboard();
  if(isLoading)return <LoadingPage title="Evaluations"/>;
  if(isError||!data)return <ErrorState title="Evaluation dashboard unavailable" onRetry={()=>refetch()}/>;
  const d=data as EvaluationDashboard;
  return <PageHeader eyebrow="GOVERNANCE / QUALITY ASSURANCE" title="Evaluation dashboard" description="A measured view of retrieval, policy, and answer quality." action={<span className="tag tag-live"><i/> LAST RUN {relativeDate(d.executedAt).toUpperCase()}</span>}>
    <div className="eval-summary-grid"><div className="panel eval-score"><div className="eyebrow">EVALUATION SUITE</div><div className="eval-score-main"><span>{d.totalCases?Math.round(d.passed/d.totalCases*100):0}<small>%</small></span><div><b>Cases passed</b><p>{d.passed} of {d.totalCases} scenarios passed in the latest run.</p></div></div><div className="eval-progress"><i style={{width:`${d.totalCases?d.passed/d.totalCases*100:0}%`}}/></div><div className="eval-totals"><span><i className="pass-dot"/> {d.passed} passed</span><span><i className="fail-dot"/> {d.failed} need review</span></div></div>
      <div className="panel metric-eval"><PanelTitle eyebrow="QUALITY INDICATORS" title="Measured dimensions"/>{d.metrics.map((m,i)=><div className="metric-eval-row" key={m.name}><span className={`metric-symbol metric-${i%4}`}><Activity size={15}/></span><span><b>{m.name}</b><small>{m.actual?"Observed":"Target"}</small></span><strong>{m.value}{m.unit}</strong></div>)}</div></div>
    <section className="panel eval-cases"><PanelTitle eyebrow="TEST COVERAGE" title="Evaluation cases" action={<span className="subtle-label">{d.cases.length} SCENARIOS</span>}/>{d.cases.length?<div className="table-wrap"><table><thead><tr><th>SCENARIO</th><th>CATEGORY</th><th>RESULT</th><th>DETAIL</th></tr></thead><tbody>{d.cases.map(c=><tr key={c.id}><td><b>{c.question}</b></td><td><span className="category-label">{c.category}</span></td><td><StatusTag value={c.result}/></td><td className="case-detail">{c.detail}</td></tr>)}</tbody></table></div>:<EmptyState title="No evaluation cases" detail="Evaluation scenarios are not available yet."/>}</section>
  </PageHeader>;
}

const demoDatasetCards: {
  dataset: DemoDatasetKey;
  title: string;
  description: string;
  icon: ReactNode;
  countLabel: string;
}[] = [
  { dataset: "incidents", title: "Store incidents", description: "Equipment alarms, refrigeration faults, and store operations signals.", icon: <AlertTriangle size={18}/>, countLabel: "incidents" },
  { dataset: "inventory", title: "Inventory discrepancies", description: "Expected versus observed stock, recount thresholds, and adjustment status.", icon: <PackageSearch size={18}/>, countLabel: "inventory events" },
  { dataset: "maintenance", title: "Maintenance records", description: "Synthetic equipment work orders with follow-up dates and assigned technicians.", icon: <Wrench size={18}/>, countLabel: "maintenance records" },
  { dataset: "handovers", title: "Shift handovers", description: "Incoming and outgoing shift notes with pending follow-up actions.", icon: <FileClock size={18}/>, countLabel: "handovers" },
  { dataset: "memory_candidates", title: "Memory review candidates", description: "Unapproved synthetic examples for testing the human governance queue.", icon: <ClipboardCheck size={18}/>, countLabel: "candidates" },
  { dataset: "evaluations", title: "Evaluation cases", description: "Missing-evidence scenarios that should produce a safe abstention.", icon: <Activity size={18}/>, countLabel: "evaluation cases" },
];

export function DemoDataStudioPage() {
  const queryClient = useQueryClient();
  const [count, setCount] = useState(12);
  const [seed, setSeed] = useState(41014);
  const [notice, setNotice] = useState("");
  const { data, isLoading, isError, refetch } = useGetDemoDataStudio();
  const refreshAffectedViews = async () => Promise.all([
    queryClient.invalidateQueries({ queryKey: getGetDemoDataStudioQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getGetOperationsDashboardQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getListIncidentsQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getListInventoryEventsQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getListMaintenanceRecordsQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getListShiftHandoversQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getListGovernanceCandidatesQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getGetEvaluationDashboardQueryKey() }),
  ]);
  const generate = useGenerateDemoData({
    mutation: {
      onSuccess: async (result: DemoDataGenerationResult) => {
        setNotice(`${result.count} synthetic ${demoDatasetCards.find(card => card.dataset === result.dataset)?.countLabel || "records"} generated in ${result.storage}.`);
        await refreshAffectedViews();
      },
    },
  });
  const reset = useResetDemoDataStudio({
    mutation: {
      onSuccess: async (result: DemoDataResetResult) => {
        setNotice(`${result.deleted} Demo Data Studio records removed. Operational records and audit history were preserved.`);
        await refreshAffectedViews();
      },
    },
  });

  if (isLoading) return <LoadingPage title="Demo Data Studio"/>;
  if (isError || !data) return <ErrorState title="Demo Data Studio unavailable" onRetry={() => refetch()}/>;
  const validInputs = Number.isInteger(count) && count >= 1 && count <= 100 && Number.isInteger(seed) && seed >= 0 && seed <= 2147483647;

  return <PageHeader
    eyebrow="MONGODB / SYNTHETIC DATA"
    title="Demo Data Studio"
    description={`Generate repeatable test records for ${data.tenantName}. Every generated row is marked synthetic and scoped to this tenant.`}
    action={<span className={`tag ${data.connected ? "tag-live" : "tag-danger"}`}><i/> {data.connected ? data.storage.toUpperCase() : "DATABASE UNAVAILABLE"}</span>}
  >
    <div className={`demo-storage-banner ${data.connected ? "connected" : "degraded"}`}>
      <span className="demo-storage-icon"><Database size={18}/></span>
      <div><b>{data.connected ? `Connected to ${data.storage}` : `${data.storage} is unavailable`}</b><small>{data.databaseName} · Tenant {data.tenantId} · {data.mode === "atlas" ? "Backend ping verified" : "In-memory demo data"}</small></div>
      <span className="demo-storage-state"><i/>{data.connected ? "READY" : "DEGRADED"}</span>
    </div>

    <section className="panel demo-counts-panel">
      <PanelTitle eyebrow="GENERATED IN THIS TENANT" title="Synthetic record counts" action={<button className="icon-button" onClick={() => refetch()} aria-label="Refresh demo data counts"><RefreshCw size={15}/></button>}/>
      <div className="demo-count-grid">{demoDatasetCards.map((card, index) => <article className="demo-count-card" key={card.dataset}><span className={`demo-count-icon tone-${index % 4}`}>{card.icon}</span><span><small>{card.title}</small><b>{data.connected ? data.counts?.[card.dataset] ?? 0 : "—"}</b></span></article>)}</div>
      <div className="demo-total"><span>Total Studio records</span><b>{data.connected ? data.total.toLocaleString() : "—"}</b></div>
    </section>

    <section className="panel demo-generator-panel">
      <PanelTitle eyebrow="DETERMINISTIC GENERATOR" title="Choose a mock dataset"/>
      <p className="demo-panel-intro">The same seed and count reproduce the same records. Re-running a dataset with the same seed refreshes only those generated records.</p>
      <div className="demo-generator-controls">
        <label>Records per run<input type="number" min={1} max={100} value={count} onChange={event => setCount(Number(event.target.value))}/><small>1–100 records</small></label>
        <label>Random seed<input type="number" min={0} max={2147483647} value={seed} onChange={event => setSeed(Number(event.target.value))}/><small>Reuse for repeatable demos</small></label>
      </div>
      <div className="demo-dataset-grid">{demoDatasetCards.map(card => <article className="demo-dataset-card" key={card.dataset}>
        <span className="demo-dataset-icon">{card.icon}</span><h3>{card.title}</h3><p>{card.description}</p>
        <button className="button button-outline" disabled={!validInputs || !data.connected || generate.isPending || reset.isPending} onClick={() => { setNotice(""); generate.mutate({ data: { dataset: card.dataset, count, seed } }); }}>
          {generate.isPending && generate.variables?.data.dataset === card.dataset ? "Generating…" : "Generate records"} <ArrowRight size={14}/>
        </button>
      </article>)}</div>
      {generate.isError && <div className="demo-feedback error" role="alert"><AlertTriangle size={15}/>{generate.error.message}</div>}
      {reset.isError && <div className="demo-feedback error" role="alert"><AlertTriangle size={15}/>{reset.error.message}</div>}
      {notice && <div className="demo-feedback success" role="status"><CheckCircle2 size={15}/>{notice}</div>}
    </section>

    <section className="panel demo-reset-panel">
      <span className="demo-reset-symbol"><ShieldCheck size={17}/></span>
      <div><b>Reset Studio-generated records</b><p>Only synthetic rows created by this page, for {data.tenantName}, are removed. Existing operational data and audit history are kept.</p></div>
      <button className="button button-outline" disabled={!data.connected || data.total === 0 || reset.isPending || generate.isPending} onClick={() => {
        if (window.confirm(`Remove ${data.total} Demo Data Studio records for ${data.tenantName}? Existing operational records and audit history will be preserved.`)) {
          setNotice("");
          reset.mutate();
        }
      }}>{reset.isPending ? "Resetting…" : "Reset mock data"}</button>
    </section>
  </PageHeader>;
}

export function SettingsPage() {
  const {data,isLoading,isError,refetch}=useGetAccessSettings();
  if(isLoading)return <LoadingPage title="Access management"/>;
  if(isError||!data)return <ErrorState title="Access settings unavailable" onRetry={()=>refetch()}/>;
  const d=data as AccessSettings;
  return <PageHeader eyebrow="GOVERNANCE / IDENTITY & POLICY" title="Access management" description="Tenant identity, store scope, and policy decisions for the current principal." action={<span className="tag tag-approved"><ShieldCheck size={13}/> ACCESS SCOPED</span>}>
    <div className="settings-grid"><section className="panel"><PanelTitle eyebrow="CURRENT PRINCIPAL" title="Identity & scope"/><div className="identity-card"><div className="avatar large">{d.currentPrincipal.displayName.split(" ").map(x=>x[0]).join("").slice(0,2)}</div><div><h3>{d.currentPrincipal.displayName}</h3><p>{d.currentPrincipal.email||"Demo principal"}</p></div><StatusTag value={d.currentPrincipal.role}/></div><div className="settings-facts"><Fact label="TENANT" value={d.tenantName}/><Fact label="ROLE" value={roleLabel(d.currentPrincipal.role)}/><Fact label="ACTIVE STORE" value={d.currentPrincipal.storeName||"All locations"}/><Fact label="PRINCIPAL ID" value={d.currentPrincipal.id} mono/></div><div className="scope-note"><ShieldCheck size={15}/><span>Data is scoped by tenant and principal permissions. Demo persona switching is isolated to the fictional demo environment.</span></div></section>
      <section className="panel"><PanelTitle eyebrow="STORE SCOPE" title="Visible locations"/>{d.stores.length?<div className="store-scope-list">{d.stores.map(s=><div key={s.storeId}><span className="scope-store-icon"><Store size={15}/></span><span><b>{s.storeName}</b><small>{s.storeId}</small></span><StatusTag value={s.status}/></div>)}</div>:<EmptyState title="No stores in scope" detail="No locations are assigned to this principal."/>}</section></div>
    <div className="settings-grid lower"><section className="panel"><PanelTitle eyebrow="ENFORCEMENT" title="Policy rules"/>{d.policyRules.length?<div className="policy-rule-list">{d.policyRules.map((rule,i)=><div key={rule}><span className="rule-count">{String(i+1).padStart(2,"0")}</span><Shield size={14}/><p>{rule}</p><CheckCircle2 size={15}/></div>)}</div>:<EmptyState title="No policy rules returned" detail="Rules will appear here when configured."/>}</section><section className="panel"><PanelTitle eyebrow="AUDIT TRAIL" title="Recent decisions"/>{d.recentDecisions.length?<div className="decision-list">{d.recentDecisions.map((x,i)=><div key={`${x.decision}-${i}`}><span className={`decision-icon ${x.decision.toLowerCase()}`}><ShieldCheck size={14}/></span><span><b>{x.decision}</b><small>{x.reason}</small></span>{x.memoryId&&<Link href={`/memories/${x.memoryId}`} className="row-open"><ArrowUpRight size={14}/></Link>}</div>)}</div>:<EmptyState title="No recent policy decisions" detail="Access evaluations will be listed here."/>}</section></div>
  </PageHeader>;
}

function IncidentCard({item,index}:{item:Incident;index:number}) {
  return <article className="panel incident-card"><div className="incident-card-top"><span className="incident-number">{String(index+1).padStart(2,"0")}</span><StatusTag value={item.status}/></div><div className="incident-category">{item.category}</div><h2>{item.title}</h2><p>{item.summary}</p><div className="incident-footer"><span><Store size={14}/>{item.storeId}</span>{item.equipmentId&&<span><Thermometer size={14}/>{item.equipmentId}</span>}<span><Clock3 size={14}/>{relativeDate(item.createdAt)}</span></div><div className="incident-severity"><span className={severityClass(item.status)}/><span>{item.status}</span></div></article>;
}
function HandoverCard({item}:{item:ShiftHandover}) {
  return <article className="panel handover-card"><div className="handover-rail"><span className={`priority-dot ${severityClass(item.priority)}`}/><span className="handover-line"/></div><div className="handover-body"><div className="handover-top"><div><div className="eyebrow">STORE {item.storeId} · {relativeDate(item.createdAt).toUpperCase()}</div><h2>{item.fromShift} <ArrowRight size={16}/> {item.toShift}</h2></div><SeverityTag value={item.priority}/></div><p>{item.summary}</p><div className="handover-bottom"><span><Store size={14}/>{item.storeId}</span><span className="pending-count"><CircleDot size={14}/>{item.pendingCount} pending items</span><span className="handover-link">SHIFT TRANSITION <ArrowUpRight size={13}/></span></div></div></article>;
}
function MaintenanceCard({item,index}:{item:MaintenanceRecord;index:number}) {
  return <article className="panel maintenance-card"><div className="maintenance-head"><div className="equipment-icon"><Wrench size={18}/></div><div className="maintenance-id"><small>RECORD {String(index+1).padStart(2,"0")}</small><b>{item.equipmentId}</b></div><StatusTag value={item.status}/></div><h2>{item.issue}</h2><div className="procedure-box"><span className="eyebrow">PROCEDURE ON FILE</span><p>{item.procedure}</p></div><div className="maintenance-footer"><span><HardHat size={14}/>{item.assignedTo}</span><span><Store size={14}/>{item.storeId}</span><span>{relativeDate(item.createdAt)}</span></div></article>;
}

function PageHeader({eyebrow,title,description,action,children}:{eyebrow:string;title:string;description?:string;action?:ReactNode;children:ReactNode}) {
  return <div className="page-content"><div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description&&<p>{description}</p>}</div>{action&&<div className="heading-actions">{action}</div>}</div>{children}</div>;
}
function DataListPage({eyebrow,title,description,count,countLabel,children}:{eyebrow:string;title:string;description:string;count:number;countLabel:string;children:ReactNode}) {
  return <PageHeader eyebrow={eyebrow} title={title} description={description} action={<span className="data-count"><Activity size={15}/>{count} {countLabel}</span>}>{children}</PageHeader>;
}
function PanelTitle({eyebrow,title,action}:{eyebrow:string;title:string;action?:ReactNode}) {
  return <div className="panel-title"><div><div className="eyebrow">{eyebrow}</div><h2>{title}</h2></div>{action&&<div>{action}</div>}</div>;
}
function MetricCard({label,value,change,tone,index}:{label:string;value:number;change:string;tone:string;index:number}) {
  return <article className={`panel metric-card metric-tone-${tone||index}`} data-testid={`metric-${label.toLowerCase().replaceAll(" ","-")}`}><div className="metric-top"><span>{label}</span><span className={`metric-trend ${tone==="negative"?"negative":""}`}>{tone==="negative"?<ArrowDownRight size={13}/>:<ArrowUpRight size={13}/>} {change}</span></div><strong>{value.toLocaleString()}</strong><div className="metric-foot"><span className="metric-bar"><i style={{width:`${54+(index*11)%42}%`}}/></span><small>vs previous 7 days</small></div></article>;
}
function ReadinessBar({label,value,max,color}:{label:string;value:number;max:number;color:string}) {
  return <div className="readiness-bar-row"><div><span>{label}</span><b>{value}</b></div><div className="bar-track"><i className={color} style={{width:`${Math.min(100,(value/max)*100)}%`}}/></div></div>;
}
function StatusTag({value}:{value:string}) {
  const val=value?.toLowerCase().replaceAll(" ","_")||"unknown";
  const cls=["approved","active","stable","resolved","completed","passed","open"].includes(val)?"approved":["candidate","pending","in_progress","review","under_review"].includes(val)?"review":["rejected","failed","critical","high","blocked"].includes(val)?"danger":["superseded","expired","closed"].includes(val)?"muted":"neutral";
  return <span className={`status-tag ${cls}`} data-testid={`status-${val}`}><i/>{value?.replaceAll("_"," ")||"Unknown"}</span>;
}
function SeverityTag({value}:{value:string}) {
  const c=severityClass(value);
  return <span className={`severity-tag ${c}`}><i/>{value}</span>;
}
function severityClass(value:string) { const v=value?.toLowerCase()||"";return v.includes("critical")||v.includes("high")||v.includes("urgent")?"high":v.includes("medium")||v.includes("elevated")?"medium":"low"; }
function Confidence({value}:{value:number}) {
  const n=value<=1?Math.round(value*100):Math.round(value);
  return <span className="confidence"><span className="confidence-track"><i style={{width:`${Math.min(100,n)}%`}}/></span><b>{n}%</b></span>;
}
function Fact({label,value,mono,marker}:{label:string;value:string;mono?:boolean;marker?:boolean}) {
  return <div className="fact"><span>{label}</span><b className={`${mono?"mono":""} ${marker?"fact-marker":""}`}>{marker&&<CheckCircle2 size={13}/>} {value}</b></div>;
}
function EmptyState({icon,title,detail,action}:{icon?:ReactNode;title:string;detail:string;action?:ReactNode}) {
  return <div className="empty-state">{icon&&<span className="empty-icon">{icon}</span>}<h3>{title}</h3><p>{detail}</p>{action&&<div className="empty-action">{action}</div>}</div>;
}
function ErrorState({title,onRetry}:{title:string;onRetry:()=>void}) {
  return <div className="error-state"><span><AlertTriangle size={18}/></span><h2>{title}</h2><p>We couldn't load this operational view. Your access and data are unchanged.</p><button className="button button-outline" onClick={onRetry}><RefreshCw size={14}/> Retry</button></div>;
}
function LoadingPage({title}:{title:string}) {
  return <div className="page-content"><div className="page-heading"><div><div className="skeleton-line short"/><div className="skeleton-line title-skeleton"/></div></div><div className="loading-grid"><div className="panel skeleton-panel"/><div className="panel skeleton-panel"/><div className="panel skeleton-panel wide"/></div><span className="sr-only">Loading {title}</span></div>;
}
function relativeDate(value:string) {
  const time=new Date(value).getTime();if(!Number.isFinite(time))return value;
  const diff=Math.max(0,Date.now()-time);const mins=Math.floor(diff/60000);
  if(mins<1)return "just now";if(mins<60)return `${mins}m ago`;
  const hrs=Math.floor(mins/60);if(hrs<24)return `${hrs}h ago`;
  const days=Math.floor(hrs/24);if(days<30)return `${days}d ago`;
  return new Intl.DateTimeFormat("en",{month:"short",day:"numeric"}).format(new Date(value));
}
function formatDate(value:string) { const date=new Date(value);return Number.isNaN(date.getTime())?value:new Intl.DateTimeFormat("en",{month:"short",day:"numeric",year:"numeric"}).format(date); }
function timeNow() { return new Intl.DateTimeFormat("en",{hour:"numeric",minute:"2-digit"}).format(new Date()); }
