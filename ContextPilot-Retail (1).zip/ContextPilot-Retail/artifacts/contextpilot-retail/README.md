# ContextPilot Retail

ContextPilot is a retail operations demo for governed, tenant-scoped memory. The included dataset is synthetic. Without `MONGODB_URI`, the API deliberately uses in-memory synthetic records so the demo can run before Atlas credentials are configured.

## Record the demo

1. Open the ContextPilot Retail preview and sign in or create a development account.
2. Use the demo persona selector to switch between the Northstar and Harbor Market examples.
3. Try the supervisor question about cooler C-14, then review its evidence, memory passport, and replay.
4. Use the review queue to correct or approve a synthetic memory. The app records the version and audit event.

The persona selector is for synthetic hackathon data only. Turn off `CONTEXT_PILOT_DEMO_IDENTITIES` and provision real Clerk memberships before connecting real operational data.

## Connect Atlas and Voyage

Atlas project and cluster provisioning must be completed through the MongoDB Atlas Hackathon Sandbox invitation; this app cannot create Atlas resources for you. Rotate the database-user password that was shared in chat, then add these values in the Replit project's **Tools → Secrets**:

- `MONGODB_URI` — the new full Atlas connection string
- `VOYAGE_API_KEY` — the Voyage API key

Do not put either value in this file, a `.env` file, or frontend code. Use a database user that can read/write the demo collections and create Atlas Search indexes. The URI password must be URL-encoded when it contains reserved characters.

After both secrets are set, seed the synthetic records from the workspace:

```sh
pnpm --filter @workspace/contextpilot-retail run seed:atlas
```

The command embeds memory records with Voyage, creates or verifies the `memory_vector` Atlas Vector Search index on `memories.embedding` (1024 dimensions, cosine similarity, tenant/store/status filters), and inserts only missing synthetic rows. It does not overwrite existing records. If an index with that name has a different definition, it stops and asks you to correct the index in Atlas rather than deleting it.

The live API uses `MONGODB_DATABASE=contextpilot_retail`, `VOYAGE_MODEL=voyage-3.5`, and `ATLAS_VECTOR_INDEX=memory_vector` by default. Missing Voyage credentials or a failed vector search are reported explicitly; Atlas retrieval does not silently fall back to lexical search.
