from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


PRIVILEGED_ROLES = {"knowledge_steward", "tenant_admin"}
READ_ROLES = {"store_manager", "knowledge_steward", "technician", "tenant_admin"}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def scope_allows(principal: dict[str, Any], record: dict[str, Any]) -> bool:
    if record.get("tenant_id") != principal.get("tenant_id"):
        return False
    record_store = record.get("store_id")
    if record_store is None and "region" in record and "name" in record:
        record_store = record.get("id")
    principal_store = principal.get("store_id")
    if record_store and principal_store and record_store != principal_store:
        return False
    if record.get("region") and principal.get("region") and record.get("region") != principal.get("region"):
        return False
    return True


def decide(
    principal: dict[str, Any],
    memory: dict[str, Any],
    operation: str = "retrieve",
    at: datetime | None = None,
) -> dict[str, Any]:
    at = at or datetime.now(timezone.utc)
    role = principal.get("role")
    if not principal.get("id"):
        return {"decision": "DENY", "reason": "No authenticated or demo principal is available.", "memoryId": memory.get("id")}
    if memory.get("tenant_id") != principal.get("tenant_id"):
        return {"decision": "DENY", "reason": "Tenant boundary does not match the principal.", "memoryId": memory.get("id")}
    if not scope_allows(principal, memory):
        return {"decision": "DENY", "reason": "Memory is outside the principal's authorized store or region scope.", "memoryId": memory.get("id")}
    if role not in READ_ROLES:
        return {"decision": "DENY", "reason": "The principal's role cannot read operational memory.", "memoryId": memory.get("id")}
    if operation in {"approve", "correct", "reject", "request_evidence", "supersede"} and role not in PRIVILEGED_ROLES:
        return {"decision": "DENY", "reason": "Only a knowledge steward or tenant admin can change memory governance.", "memoryId": memory.get("id")}
    if memory.get("sensitivity") == "restricted" and role not in PRIVILEGED_ROLES:
        return {"decision": "REVIEW", "reason": "Restricted memory requires a steward review.", "memoryId": memory.get("id")}
    if operation == "retrieve":
        if memory.get("status") != "approved":
            return {"decision": "DENY", "reason": f"Memory status is {memory.get('status')}, not approved.", "memoryId": memory.get("id")}
        effective_at = _date(memory.get("effective_at"))
        expires_at = _date(memory.get("expires_at"))
        if effective_at and effective_at > at:
            return {"decision": "DENY", "reason": "Memory is not yet effective.", "memoryId": memory.get("id")}
        if expires_at and expires_at <= at:
            return {"decision": "DENY", "reason": "Memory has expired and cannot be current guidance.", "memoryId": memory.get("id")}
    return {"decision": "ALLOW", "reason": "Principal, scope, role, lifecycle, and requested operation are allowed.", "memoryId": memory.get("id")}


def _date(value: Any) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
