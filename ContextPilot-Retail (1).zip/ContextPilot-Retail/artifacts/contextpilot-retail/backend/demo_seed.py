from __future__ import annotations

from datetime import datetime, timedelta, timezone
import random
import re
from typing import Any

BASE_TIME = datetime(2026, 11, 14, 12, 0, tzinfo=timezone.utc)


def iso(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def make_demo_data() -> dict[str, list[dict[str, Any]]]:
    """Build stable fictional records for the ContextPilot demonstration."""
    stores: list[dict[str, Any]] = []
    store_codes = ["014", "021", "032", "045", "053", "067", "074", "081", "096", "108"]
    regions = ["GTA West", "GTA East", "Golden Horseshoe"]
    for index, code in enumerate(store_codes):
        stores.append(
            {
                "id": code,
                "tenant_id": "northstar",
                "name": f"Northstar {['Westgate', 'Lakeshore', 'Cedar Park', 'Harbourfront', 'Maple Ridge'][index % 5]}",
                "region": regions[index % len(regions)],
                "city": ["Toronto", "Mississauga", "Oakville", "Brampton", "Hamilton"][index % 5],
                "status": "Operational",
            }
        )
    stores.append(
        {
            "id": "HBR-001",
            "tenant_id": "harbor-market",
            "name": "Harbor Market — Queen Street",
            "region": "Toronto Core",
            "city": "Toronto",
            "status": "Operational",
        }
    )

    principals = [
        {
            "id": "demo-northstar-manager-014",
            "display_name": "Jordan Lee",
            "email": "jordan.lee@northstar.example",
            "role": "store_manager",
            "tenant_id": "northstar",
            "tenant_name": "Northstar Grocery",
            "store_id": "014",
            "store_name": "Northstar Westgate",
            "region": "GTA West",
        },
        {
            "id": "demo-northstar-steward",
            "display_name": "Maya Chen",
            "email": "maya.chen@northstar.example",
            "role": "knowledge_steward",
            "tenant_id": "northstar",
            "tenant_name": "Northstar Grocery",
            "store_id": None,
            "store_name": "All Northstar stores",
            "region": None,
        },
        {
            "id": "demo-northstar-technician-014",
            "display_name": "Alex Morgan",
            "email": "alex.morgan@northstar.example",
            "role": "technician",
            "tenant_id": "northstar",
            "tenant_name": "Northstar Grocery",
            "store_id": "014",
            "store_name": "Northstar Westgate",
            "region": "GTA West",
        },
        {
            "id": "demo-harbor-manager-001",
            "display_name": "Riley Park",
            "email": "riley.park@harbor.example",
            "role": "store_manager",
            "tenant_id": "harbor-market",
            "tenant_name": "Harbor Market",
            "store_id": "HBR-001",
            "store_name": "Harbor Market — Queen Street",
            "region": "Toronto Core",
        },
    ]

    employees: list[dict[str, Any]] = []
    for index in range(10):
        employees.append(
            {
                "id": f"ns-manager-{index + 1:02d}",
                "tenant_id": "northstar",
                "store_id": store_codes[index],
                "name": f"Store Manager {index + 1:02d}",
                "role": "store_manager",
            }
        )
    for index in range(5):
        employees.append(
            {
                "id": f"ns-tech-{index + 1:02d}",
                "tenant_id": "northstar",
                "store_id": store_codes[index],
                "name": f"Facilities Technician {index + 1:02d}",
                "role": "technician",
            }
        )
    for index in range(2):
        employees.append(
            {
                "id": f"ns-steward-{index + 1:02d}",
                "tenant_id": "northstar",
                "store_id": None,
                "name": f"Knowledge Steward {index + 1:02d}",
                "role": "knowledge_steward",
            }
        )
    for index in range(23):
        employees.append(
            {
                "id": f"ns-associate-{index + 1:02d}",
                "tenant_id": "northstar",
                "store_id": store_codes[index % len(store_codes)],
                "name": f"Retail Associate {index + 1:02d}",
                "role": "associate",
            }
        )
    employees.extend(
        [
            {
                "id": "harbor-manager-01",
                "tenant_id": "harbor-market",
                "store_id": "HBR-001",
                "name": "Harbor Store Manager",
                "role": "store_manager",
            },
            {
                "id": "harbor-steward-01",
                "tenant_id": "harbor-market",
                "store_id": "HBR-001",
                "name": "Harbor Knowledge Steward",
                "role": "knowledge_steward",
            },
        ]
    )

    incidents: list[dict[str, Any]] = []
    incident_types = [
        ("Refrigeration", "cooler", "temperature alert"),
        ("Freezer", "freezer", "temperature excursion"),
        ("Compressor", "compressor", "service interruption"),
        ("Inventory", "stock count", "count variance"),
        ("Supplier", "delivery", "supplier delay"),
    ]
    for index in range(100):
        category, subject, detail = incident_types[index % len(incident_types)]
        store_id = store_codes[index % len(store_codes)]
        equipment_id = "C-14" if index < 3 else (f"F-{index % 9 + 1:02d}" if index % 5 == 1 else None)
        title = (
            f"Cooler C-14 {['temperature alarm', 'repeat trip', 'compressor vibration'][index]}"
            if index < 3
            else f"{subject.title()} {detail} — Store {store_id}"
        )
        incidents.append(
            {
                "id": f"inc-ns-{index + 1:03d}",
                "tenant_id": "northstar",
                "store_id": store_id,
                "title": title,
                "category": category,
                "status": "Open" if index % 4 == 0 else ("Monitoring" if index % 4 == 1 else "Resolved"),
                "summary": (
                    "C-14 has tripped twice during the evening shift; temperature logs are attached."
                    if index < 3
                    else f"Team reported a {detail} involving {subject.lower()}."
                ),
                "equipment_id": equipment_id,
                "created_at": iso(BASE_TIME - timedelta(hours=2 + index * 3)),
            }
        )

    source_documents: list[dict[str, Any]] = []
    for index in range(60):
        is_c14 = index == 0
        source_documents.append(
            {
                "id": "src-facilities-procedure-014" if is_c14 else f"src-ns-{index:03d}",
                "tenant_id": "northstar",
                "store_id": "014" if is_c14 else store_codes[index % len(store_codes)],
                "title": "Facilities procedure — C-14 repeat failures" if is_c14 else f"Operations source {index + 1:02d}",
                "author": "Facilities Dispatch" if is_c14 else f"Northstar Operations {index % 8 + 1:02d}",
                "revision": "rev-2026-11" if is_c14 else f"rev-{index % 4 + 1}",
                "content_hash": f"sha256-demo-{index + 1:064x}",
                "excerpt": (
                    "For repeat faults, isolate the cooler, preserve temperature logs, and contact Facilities Dispatch. "
                    "Do not repeatedly reset the breaker. Escalate product safety concerns to the duty manager."
                    if is_c14
                    else f"Approved operating note for {store_codes[index % len(store_codes)]}: {incident_types[index % len(incident_types)][2]}."
                ),
                "created_at": iso(BASE_TIME - timedelta(days=1 + index)),
            }
        )

    memories: list[dict[str, Any]] = []
    categories = ["Maintenance", "Food Safety", "Inventory", "Shift Handover", "Supplier"]
    for index in range(80):
        if index == 0:
            memory = {
                "id": "mem-c14",
                "tenant_id": "northstar",
                "store_id": "014",
                "region": "GTA West",
                "title": "Cooler C-14 repeat fault guidance",
                "text": "If cooler C-14 trips, reset the breaker once and monitor the unit. Call maintenance only if it trips again.",
                "category": "Maintenance",
                "type": "operational_procedure",
                "status": "approved",
                "version": 1,
                "confidence": 0.84,
                "source_ids": ["src-ns-001"],
                "author": "Facilities Team",
                "reviewer": "Maya Chen",
                "verification_status": "verified",
                "effective_at": "2025-02-01T00:00:00Z",
                "expires_at": "2027-02-01T00:00:00Z",
                "review_at": "2026-12-01T00:00:00Z",
                "sensitivity": "operational",
                "source_revision": "rev-2025-02",
                "source_hash": "sha256-outdated-c14-procedure",
                "equipment_ids": ["C-14"],
                "created_at": "2025-02-01T00:00:00Z",
                "updated_at": "2026-01-15T00:00:00Z",
            }
        elif index == 1:
            memory = {
                "id": "mem-expired-workaround-014",
                "tenant_id": "northstar",
                "store_id": "014",
                "region": "GTA West",
                "title": "Temporary freezer reset workaround",
                "text": "An old temporary reset workaround that is no longer valid.",
                "category": "Maintenance",
                "type": "temporary_workaround",
                "status": "approved",
                "version": 1,
                "confidence": 0.51,
                "source_ids": ["src-ns-002"],
                "author": "Facilities Team",
                "reviewer": "Maya Chen",
                "verification_status": "expired",
                "effective_at": "2024-02-01T00:00:00Z",
                "expires_at": "2025-02-01T00:00:00Z",
                "review_at": "2025-01-15T00:00:00Z",
                "sensitivity": "operational",
                "source_revision": "rev-2024-02",
                "source_hash": "sha256-expired-workaround",
                "equipment_ids": ["F-02"],
                "created_at": "2024-02-01T00:00:00Z",
                "updated_at": "2025-02-01T00:00:00Z",
            }
        elif index == 2:
            memory = {
                "id": "mem-superseded-compressor",
                "tenant_id": "northstar",
                "store_id": "014",
                "region": "GTA West",
                "title": "Compressor restart procedure (superseded)",
                "text": "A retired compressor restart procedure. Do not use as current guidance.",
                "category": "Maintenance",
                "type": "operational_procedure",
                "status": "superseded",
                "version": 1,
                "confidence": 0.4,
                "source_ids": ["src-ns-003"],
                "author": "Facilities Team",
                "reviewer": "Maya Chen",
                "verification_status": "superseded",
                "effective_at": "2024-01-01T00:00:00Z",
                "expires_at": None,
                "review_at": None,
                "sensitivity": "operational",
                "source_revision": "rev-2024-01",
                "source_hash": "sha256-superseded-compressor",
                "equipment_ids": ["C-14"],
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2025-09-01T00:00:00Z",
            }
        else:
            store_id = store_codes[index % len(store_codes)]
            category = categories[index % len(categories)]
            equipment = f"C-{index % 14 + 1:02d}" if category == "Maintenance" else None
            memory = {
                "id": f"mem-ns-{index + 1:03d}",
                "tenant_id": "northstar",
                "store_id": store_id,
                "region": regions[index % len(regions)],
                "title": f"{category} operating memory {index + 1:02d}",
                "text": (
                    f"Approved {category.lower()} guidance for Store {store_id}: verify the source record, "
                    "document the observed condition, and notify the responsible shift lead."
                ),
                "category": category,
                "type": "incident_pattern" if index % 3 == 0 else "operational_procedure",
                "status": "approved",
                "version": 1,
                "confidence": round(0.72 + (index % 20) / 100, 2),
                "source_ids": [f"src-ns-{index % 60 + 1:03d}"],
                "author": f"Northstar Operations {index % 8 + 1:02d}",
                "reviewer": "Maya Chen" if index % 4 == 0 else "Regional Steward",
                "verification_status": "verified",
                "effective_at": iso(BASE_TIME - timedelta(days=40 + index)),
                "expires_at": None,
                "review_at": iso(BASE_TIME + timedelta(days=90)),
                "sensitivity": "operational",
                "source_revision": f"rev-{index % 4 + 1}",
                "source_hash": f"sha256-ns-memory-{index + 1:03d}",
                "equipment_ids": [equipment] if equipment else [],
                "created_at": iso(BASE_TIME - timedelta(days=40 + index)),
                "updated_at": iso(BASE_TIME - timedelta(days=5 + index % 10)),
            }
        memories.append(memory)

    harbor_memories = [
        {
            "id": f"mem-harbor-{index + 1:02d}",
            "tenant_id": "harbor-market",
            "store_id": "HBR-001",
            "region": "Toronto Core",
            "title": "Harbor Market operations memory" if index == 0 else f"Harbor Market procedure {index + 1:02d}",
            "text": (
                "Harbor Market's own refrigeration history is stored separately from Northstar Grocery."
                if index == 0
                else f"Approved Harbor Market procedure {index + 1:02d} for local operations."
            ),
            "category": "Maintenance" if index == 0 else categories[index % len(categories)],
            "type": "incident_pattern",
            "status": "approved",
            "version": 1,
            "confidence": 0.81,
            "source_ids": [f"src-harbor-{index + 1:02d}"],
            "author": "Harbor Market Operations",
            "reviewer": "Harbor Knowledge Steward",
            "verification_status": "verified",
            "effective_at": "2026-01-01T00:00:00Z",
            "expires_at": None,
            "review_at": None,
            "sensitivity": "operational",
            "source_revision": "rev-1",
            "source_hash": f"sha256-harbor-memory-{index + 1:02d}",
            "equipment_ids": ["C-14"] if index == 0 else [],
            "created_at": iso(BASE_TIME - timedelta(days=20 + index)),
            "updated_at": iso(BASE_TIME - timedelta(days=2)),
        }
        for index in range(8)
    ]
    memories.extend(harbor_memories)

    handovers = [
        {
            "id": f"handover-ns-{index + 1:03d}",
            "tenant_id": "northstar",
            "store_id": store_codes[index % len(store_codes)],
            "from_shift": "Evening",
            "to_shift": "Opening",
            "priority": ["High", "Medium", "Low"][index % 3],
            "summary": "Monitor C-14 temperature trend and confirm Facilities Dispatch follow-up."
            if index == 0
            else f"Review pending tasks and stock notes for Store {store_codes[index % len(store_codes)]}.",
            "pending_count": index % 4,
            "created_at": iso(BASE_TIME - timedelta(hours=index * 5)),
        }
        for index in range(30)
    ]

    inventory_events = [
        {
            "id": f"inventory-ns-{index + 1:03d}",
            "tenant_id": "northstar",
            "store_id": store_codes[index % len(store_codes)],
            "sku": f"SKU-{41000 + index}",
            "product": ["Dairy case pack", "Frozen berries", "Fresh poultry", "Bakery flour", "Leafy greens"][index % 5],
            "discrepancy": f"{(index % 7) + 1} units {['short', 'over'][index % 2]}",
            "severity": ["High", "Medium", "Low"][index % 3],
            "status": "Open" if index % 3 != 0 else "Resolved",
            "created_at": iso(BASE_TIME - timedelta(hours=index * 7)),
        }
        for index in range(40)
    ]

    maintenance_records = [
        {
            "id": f"maintenance-ns-{index + 1:03d}",
            "tenant_id": "northstar",
            "store_id": store_codes[index % len(store_codes)],
            "equipment_id": "C-14" if index == 0 else f"F-{index % 12 + 1:02d}",
            "issue": "Repeat temperature alarm and breaker trip" if index == 0 else f"Routine {['compressor inspection', 'seal repair', 'temperature sensor check'][index % 3]}",
            "status": ["Open", "In progress", "Closed"][index % 3],
            "assigned_to": f"Facilities Technician {index % 5 + 1:02d}",
            "created_at": iso(BASE_TIME - timedelta(days=index)),
            "procedure": "Use the approved C-14 repeat-fault procedure; isolate, retain temperature logs, and contact Facilities Dispatch."
            if index == 0
            else "Follow the current equipment work order and record all readings.",
        }
        for index in range(20)
    ]

    candidates = [
        {
            "id": "candidate-c14-procedure",
            "tenant_id": "northstar",
            "store_id": "014",
            "title": "C-14 repeat-fault escalation procedure",
            "proposed_text": (
                "For repeat faults, isolate cooler C-14, preserve temperature logs, and contact Facilities Dispatch. "
                "Do not repeatedly reset the breaker. Escalate product safety concerns to the duty manager."
            ),
            "source_excerpt": (
                "For repeat faults, isolate the cooler, preserve temperature logs, and contact Facilities Dispatch. "
                "Do not repeatedly reset the breaker. Escalate product safety concerns to the duty manager."
            ),
            "source_author": "Facilities Dispatch",
            "source_ids": ["src-facilities-procedure-014"],
            "confidence": 0.96,
            "possible_duplicates": ["Cooler C-14 repeat fault guidance"],
            "possible_contradictions": ["mem-c14 — breaker reset guidance"],
            "suggested_expiry": "2027-11-14T00:00:00Z",
            "existing_memory_id": "mem-c14",
            "existing_version": 1,
            "status": "pending",
            "created_at": iso(BASE_TIME - timedelta(hours=3)),
        },
        *[
            {
                "id": f"candidate-ns-{index + 1:02d}",
                "tenant_id": "northstar",
                "store_id": store_codes[index + 1],
                "title": f"Review candidate — Store {store_codes[index + 1]}",
                "proposed_text": f"Verify the source record before applying the updated operating procedure at Store {store_codes[index + 1]}.",
                "source_excerpt": f"Source record confirms the revised local procedure for Store {store_codes[index + 1]}.",
                "source_author": "Northstar Operations",
                "source_ids": [f"src-ns-{index + 4:03d}"],
                "confidence": round(0.78 + index * 0.02, 2),
                "possible_duplicates": [],
                "possible_contradictions": [],
                "suggested_expiry": "2027-06-01T00:00:00Z",
                "existing_memory_id": None,
                "status": "pending",
                "created_at": iso(BASE_TIME - timedelta(days=index + 1)),
            }
            for index in range(5)
        ],
    ]

    evaluation_cases = []
    store_014_memories = [
        memory
        for memory in memories
        if memory.get("store_id") == "014"
        and memory.get("status") == "approved"
        and memory.get("id") != "mem-expired-workaround-014"
    ]
    for index in range(40):
        if index == 0:
            question = "Have we experienced cooler C-14 failures before?"
            expected_id = "mem-c14"
            category = "retrieval"
            expected_abstention = False
        elif index == 1:
            question = "What is the approved C-14 repeat-fault escalation procedure?"
            expected_id = "mem-c14"
            category = "citation"
            expected_abstention = False
        elif index == 2:
            question = "What is Harbor Market's C-14 history?"
            expected_id = None
            category = "tenant_isolation"
            expected_abstention = True
        elif index == 3:
            question = "Can I use the expired freezer reset workaround?"
            expected_id = None
            category = "lifecycle"
            expected_abstention = True
        elif index == 4:
            question = "What was the superseded compressor restart procedure?"
            expected_id = None
            category = "lifecycle"
            expected_abstention = True
        elif index == 5:
            question = "What is in the unapproved candidate CANDIDATE-C14?"
            expected_id = None
            category = "unapproved"
            expected_abstention = True
        else:
            memory = store_014_memories[(index - 6) % len(store_014_memories)]
            question = f"Show approved memory {memory['id']} for Store 014."
            expected_id = memory["id"]
            category = "retrieval"
            expected_abstention = False
        evaluation_cases.append(
            {
                "id": f"eval-{index + 1:02d}",
                "tenant_id": "northstar",
                "question": question,
                "category": category,
                "expected_memory_id": expected_id,
                "expected_abstention": expected_abstention,
            }
        )

    sources_harbor = [
        {
            "id": f"src-harbor-{index + 1:02d}",
            "tenant_id": "harbor-market",
            "store_id": "HBR-001",
            "title": f"Harbor Market source {index + 1:02d}",
            "author": "Harbor Market Operations",
            "revision": "rev-1",
            "content_hash": f"sha256-harbor-source-{index + 1:02d}",
            "excerpt": "Fictional Harbor Market operating record.",
            "created_at": iso(BASE_TIME - timedelta(days=index + 1)),
        }
        for index in range(8)
    ]

    return {
        "tenants": [
            {"id": "northstar", "name": "Northstar Grocery", "regions": regions},
            {"id": "harbor-market", "name": "Harbor Market", "regions": ["Toronto Core"]},
        ],
        "stores": stores,
        "principals": principals,
        "employees": employees,
        "source_documents": source_documents + sources_harbor,
        "source_revisions": [],
        "incidents": incidents + [
            {
                "id": "inc-harbor-001",
                "tenant_id": "harbor-market",
                "store_id": "HBR-001",
                "title": "Harbor Market refrigeration sensor check",
                "category": "Refrigeration",
                "status": "Resolved",
                "summary": "Fictional Harbor Market maintenance record; not shared with Northstar.",
                "equipment_id": "C-14",
                "created_at": iso(BASE_TIME - timedelta(days=3)),
            }
        ],
        "inventory_events": inventory_events,
        "shift_handovers": handovers,
        "maintenance_records": maintenance_records,
        "memories": memories,
        "memory_versions": [
            {
                "id": "mem-c14-v1",
                "memory_id": "mem-c14",
                "tenant_id": "northstar",
                "version": 1,
                "text": "If cooler C-14 trips, reset the breaker once and monitor the unit. Call maintenance only if it trips again.",
                "status": "approved",
                "author": "Facilities Team",
                "reviewer": "Maya Chen",
                "source_ids": ["src-ns-001"],
                "created_at": "2025-02-01T00:00:00Z",
            }
        ],
        "memory_events": [
            {
                "id": "evt-c14-v1-approved",
                "tenant_id": "northstar",
                "store_id": "014",
                "memory_id": "mem-c14",
                "action": "approved",
                "actor": "Maya Chen",
                "detail": "Version 1 was approved from the earlier facilities note.",
                "created_at": "2025-02-01T00:00:00Z",
            },
            {
                "id": "evt-expired-workaround",
                "tenant_id": "northstar",
                "store_id": "014",
                "memory_id": "mem-expired-workaround-014",
                "action": "expired",
                "actor": "System",
                "detail": "The temporary freezer workaround reached its expiry date.",
                "created_at": "2025-02-01T00:00:00Z",
            },
        ],
        "memory_relationships": [],
        "retrieval_runs": [],
        "agent_runs": [],
        "evaluation_cases": evaluation_cases,
        "evaluation_results": [],
        "audit_events": [],
        "governance_candidates": candidates,
    }


DEMO_PRINCIPAL_IDS = {
    "demo-northstar-manager-014",
    "demo-northstar-steward",
    "demo-northstar-technician-014",
    "demo-harbor-manager-001",
}


DEMO_STUDIO_COLLECTIONS = {
    "incidents": "incidents",
    "inventory": "inventory_events",
    "maintenance": "maintenance_records",
    "handovers": "shift_handovers",
    "memory_candidates": "governance_candidates",
    "evaluations": "evaluation_cases",
}


def make_demo_studio_records(
    dataset: str,
    tenant_id: str,
    store_ids: list[str],
    count: int,
    seed: int,
) -> list[dict[str, Any]]:
    """Create reproducible, tenant-scoped records for the Demo Data Studio."""
    if dataset not in DEMO_STUDIO_COLLECTIONS:
        raise ValueError(f"Unsupported demo dataset: {dataset}")
    if count < 1 or count > 100:
        raise ValueError("Record count must be between 1 and 100.")
    if seed < 0 or seed > 2_147_483_647:
        raise ValueError("Seed must be between 0 and 2147483647.")

    safe_tenant = re.sub(r"[^a-z0-9-]+", "-", tenant_id.lower()).strip("-") or "tenant"
    rng = random.Random(seed)
    available_stores = sorted(set(store_ids)) or ["DEMO-001"]
    records: list[dict[str, Any]] = []
    categories = ["Refrigeration", "Freezer", "Inventory", "Supplier", "Food Safety"]
    products = ["Dairy case pack", "Frozen berries", "Fresh poultry", "Bakery flour", "Leafy greens"]
    equipment = ["C-14", "F-02", "C-08", "R-03", "F-11"]
    names = ["Taylor Reed", "Avery Singh", "Morgan Ellis", "Jamie Park", "Casey Brooks"]

    for index in range(count):
        store_id = rng.choice(available_stores)
        created_at = iso(BASE_TIME - timedelta(hours=rng.randint(1, 24 * 150)))
        record_id = f"studio-{safe_tenant}-{dataset}-{seed}-{index + 1:03d}"
        common = {
            "id": record_id,
            "tenant_id": tenant_id,
            "store_id": store_id,
            "created_at": created_at,
            "demo_dataset": True,
            "demo_dataset_type": dataset,
            "demo_seed": seed,
            "synthetic_demo_data": True,
        }

        if dataset == "incidents":
            unit = rng.choice(equipment)
            category = rng.choice(categories)
            record = {
                **common,
                "title": f"{unit} {rng.choice(['temperature alert', 'repeat fault', 'inspection required'])} — Store {store_id}",
                "category": category,
                "status": rng.choice(["Open", "Monitoring", "Resolved"]),
                "summary": f"Synthetic {category.lower()} incident logged for {unit}; review the linked store record and follow the approved escalation path.",
                "equipment_id": unit,
            }
        elif dataset == "inventory":
            expected = rng.randint(18, 140)
            observed = max(0, expected + rng.choice([-9, -6, -3, -1, 1, 2, 5, 8]))
            difference = observed - expected
            record = {
                **common,
                "sku": f"SKU-{rng.randint(41000, 49999)}",
                "product": rng.choice(products),
                "expected_quantity": expected,
                "observed_quantity": observed,
                "difference": difference,
                "discrepancy": f"{abs(difference)} units {'over' if difference > 0 else 'short'}",
                "severity": "High" if abs(difference) >= 6 else ("Medium" if abs(difference) >= 3 else "Low"),
                "employee": rng.choice(names),
                "recount_status": "Required" if abs(difference) >= 5 else "Not required",
                "adjustment_status": rng.choice(["Pending", "Completed"]),
                "status": rng.choice(["Open", "Resolved"]),
            }
        elif dataset == "maintenance":
            unit = rng.choice(equipment)
            issue = rng.choice(
                ["temperature sensor check", "door seal inspection", "compressor vibration review", "scheduled coil cleaning"]
            )
            record = {
                **common,
                "equipment_id": unit,
                "issue": f"{unit} — {issue}",
                "status": rng.choice(["Open", "In progress", "Closed"]),
                "assigned_to": rng.choice(names),
                "procedure": "Synthetic demo record only. Use the approved facilities procedure and current work order; this record is not repair guidance.",
                "diagnosis": f"Demo diagnosis: {issue} requires technician review.",
                "work_performed": "Inspection recorded; consult the authorized facilities workflow before acting.",
                "parts_used": [],
                "resolution_state": rng.choice(["Awaiting review", "Monitoring", "Resolved"]),
                "follow_up_at": iso(BASE_TIME + timedelta(days=rng.randint(1, 21))),
            }
        elif dataset == "handovers":
            pending = rng.randint(0, 4)
            record = {
                **common,
                "from_shift": rng.choice(["Opening", "Day", "Evening"]),
                "to_shift": rng.choice(["Day", "Evening", "Closing"]),
                "priority": rng.choice(["High", "Medium", "Low"]),
                "summary": f"Synthetic handover for Store {store_id}: review open work, confirm equipment readings, and assign any pending follow-up.",
                "pending_count": pending,
                "open_incidents": [],
                "temperature_observations": [],
                "inventory_concerns": [],
                "maintenance_tickets": [],
                "follow_up_actions": ["Review the open items with the incoming shift"] if pending else [],
                "outgoing_employee": rng.choice(names),
                "incoming_employee": rng.choice(names),
                "shift_date": created_at,
            }
        elif dataset == "memory_candidates":
            record = {
                **common,
                "title": f"Demo review candidate {index + 1:02d} — Store {store_id}",
                "proposed_text": f"Synthetic candidate for Store {store_id}: verify the source record, document observed conditions, and route unresolved operational questions to the responsible team.",
                "source_excerpt": "Synthetic example for governance workflow testing. This is not an approved operating procedure.",
                "source_author": "ContextPilot Demo Generator",
                "source_ids": [],
                "confidence": round(rng.uniform(0.72, 0.97), 2),
                "possible_duplicates": [],
                "possible_contradictions": [],
                "suggested_expiry": iso(BASE_TIME + timedelta(days=180)),
                "existing_memory_id": None,
                "status": "pending",
            }
        else:
            record = {
                **common,
                "question": f"STUDIO-NO-EVIDENCE-{seed}-{index + 1:03d}",
                "category": "missing_evidence",
                "expected_memory_id": None,
                "expected_abstention": True,
            }

        records.append(record)
    return records
