from __future__ import annotations

import os

import httpx


async def embed_text(text: str) -> list[float]:
    api_key = os.getenv("VOYAGE_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "VOYAGE_API_KEY is required for Atlas retrieval. "
            "Add it to the backend Secrets; retrieval will not silently fall back."
        )
    model = os.getenv("VOYAGE_MODEL", "voyage-3.5")
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.post(
            "https://api.voyageai.com/v1/embeddings",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"input": [text], "model": model, "input_type": "query"},
        )
        response.raise_for_status()
        body = response.json()
        vectors = body.get("data")
        if not isinstance(vectors, list) or not vectors:
            raise RuntimeError("Voyage returned no embedding for the query.")
        embedding = vectors[0].get("embedding")
        if not isinstance(embedding, list) or len(embedding) != 1024:
            raise RuntimeError(
                "Voyage returned an unexpected vector size. "
                "The configured Atlas index requires 1024 dimensions."
            )
        return [float(value) for value in embedding]
