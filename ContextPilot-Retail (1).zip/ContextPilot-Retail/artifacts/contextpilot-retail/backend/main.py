from __future__ import annotations

import base64
import os
import re
from datetime import datetime, timezone
from functools import lru_cache
from typing import Any, Literal
from uuid import uuid4

import jwt
from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from jwt import PyJWKClient
from pydantic import BaseModel, Field

from .agent import ask_with_langgraph, retrieve_eligible
from .demo_seed import (
    DEMO_PRINCIPAL_IDS,
    DEMO_STUDIO_COLLECTIONS,
    make_demo_studio_records,
)
from .embeddings import embed_text
from .policy import PRIVILEGED_ROLES, decide, now_iso, scope_allows
from .repository import MemoryRepository, MongoRepository, create_repository

Repository = MemoryRepository | MongoRepository
repository, DATA_MODE = create_repository()
DEMO_IDENTITIES_ENABLED = DATA_MODE == "demo" or os.getenv(
    "CONTEXT_PILOT_DEMO_IDENTITIES", "false"
).strip().lower() in {"1", "true", "yes"}
app = FastAPI(
    title="ContextPilot Retail API",
    description="Tenant-scoped, auditable retail memory and operations endpoints.",
    version="0.1.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[],
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["Content-Type"],
)
API = "/api/contextpilot"


class DemoPrincipalInput(BaseModel):
    principalId: str = Field(min_length=1, max_length=100)


class QuestionInput(BaseModel):
    question: str = Field(min_length=3, max_length=2000)


class GovernanceDecisionInput(BaseModel):
    action: str = Field(pattern="^(approve|reject|request_evidence|correct|supersede)$")
    correctedText: str | None = Field(default=None, max_length=8000)
    note: str | None = Field(default=None, max_length=2000)
    expiresAt: str | None = None


class DemoDataGenerateInput(BaseModel):
    dataset: Literal[
        "incidents",
        "inventory",
        "maintenance",
        "handovers",
        "memory_candidates",
        "evaluations",
    ]
    count: int = Field(default=12, ge=1, le=100)
    seed: int = Field(default=41014, ge=0, le=2_147_483_647)


def _api_principal(principal: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": principal["id"],
        "displayName": principal.get("display_name", principal.get("displayName", "User")),
        "email": principal.get("email", ""),
        "role": principal["role"],
        "tenantId": principal["tenant_id"],
        "tenantName": principal.get("tenant_name", ""),
        "storeId": principal.get("store_id"),
        "storeName": principal.get("store_name"),
    }


def _permissions(role: str) -> list[str]:
    permissions = ["operations:read", "memory:read", "supervisor:ask"]
    if role in PRIVILEGED_ROLES:
        permissions.extend(["memory:review", "memory:correct", "access:read"])
    if role == "technician":
        permissions.extend(["maintenance:read", "maintenance:update"])
    return permissions


def _publishable_host() -> str:
    key = os.getenv("CLERK_PUBLISHABLE_KEY", "").strip()
    if not key:
        raise HTTPException(status_code=503, detail="Clerk authentication is not configured.")
    encoded = key.split("_", 2)[-1]
    try:
        decoded = base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)).decode("utf-8")
    except Exception as error:
        raise HTTPException(status_code=503, detail="Clerk publishable key is invalid.") from error
    host = decoded.split("$", 1)[0].strip().rstrip("/")
    if host.startswith("https://"):
        host = host.removeprefix("https://")
    if host.startswith("http://"):
        host = host.removeprefix("http://")
    if not host or "/" in host:
        raise HTTPException(status_code=503, detail="Clerk Frontend API host could not be resolved.")
    return host


@lru_cache(maxsize=4)
def _jwks_client(host: str) -> PyJWKClient:
    return PyJWKClient(f"https://{host}/.well-known/jwks.json", cache_keys=True)


def _clerk_user_id(request: Request) -> str:
    token = request.cookies.get("__session")
    if not token:
        raise HTTPException(status_code=401, detail="Sign in to access this workspace.")
    host = _publishable_host()
    try:
        signing_key = _jwks_client(host).get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token,
            signing_key,
            algorithms=["RS256"],
            options={"verify_aud": False},
            issuer=f"https://{host}",
        )
    except Exception as error:
        raise HTTPException(status_code=401, detail="The sign-in session could not be verified.") from error
    user_id = claims.get("sub")
    if not isinstance(user_id, str) or not user_id:
        raise HTTPException(status_code=401, detail="The sign-in session has no user identity.")
    return user_id


def current_principal(request: Request) -> dict[str, Any]:
    if DEMO_IDENTITIES_ENABLED:
        principal_id = request.cookies.get("contextpilot_demo_actor", "demo-northstar-manager-014")
        if principal_id not in DEMO_PRINCIPAL_IDS:
            raise HTTPException(status_code=401, detail="The selected demo identity is not allowed.")
        principal = repository.find_one("principals", {"id": principal_id})
        if not principal:
            raise HTTPException(status_code=401, detail="The selected demo identity is not available.")
        return principal

    user_id = _clerk_user_id(request)
    principal = repository.find_one("principals", {"clerk_user_id": user_id})
    if not principal:
        raise HTTPException(
            status_code=403,
            detail="Your account is signed in but has no approved ContextPilot role. Ask a tenant administrator to provision your membership.",
        )
    return principal


def _tenant_rows(name: str, principal: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        row
        for row in repository.all(name, {"tenant_id": principal["tenant_id"]})
        if scope_allows(principal, row)
    ]


def _effective_status(memory: dict[str, Any]) -> str:
    if memory.get("status") == "approved":
        expiry = _parse_date(memory.get("expires_at"))
        effective = _parse_date(memory.get("effective_at"))
        now = datetime.now(timezone.utc)
        if expiry and expiry <= now:
            return "expired"
        if effective and effective > now:
            return "candidate"
    return memory.get("status", "candidate")


def _memory_summary(memory: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": memory["id"],
        "title": memory.get("title", "Untitled memory"),
        "text": memory.get("text", ""),
        "category": memory.get("category", "Operations"),
        "type": memory.get("type", "operational_note"),
        "status": _effective_status(memory),
        "tenantId": memory["tenant_id"],
        "storeId": memory.get("store_id"),
        "version": int(memory.get("version", 1)),
        "confidence": float(memory.get("confidence", 0)),
        "sourceIds": memory.get("source_ids", []),
        "expiresAt": memory.get("expires_at"),
        "updatedAt": memory.get("updated_at", memory.get("created_at", now_iso())),
    }


def _event(event: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": event.get("id", ""),
        "action": event.get("action", "updated"),
        "actor": event.get("actor", "System"),
        "detail": event.get("detail", ""),
        "createdAt": event.get("created_at", event.get("createdAt", now_iso())),
    }


def _candidate(candidate: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": candidate["id"],
        "title": candidate.get("title", "Memory candidate"),
        "proposedText": candidate.get("proposed_text", ""),
        "sourceExcerpt": candidate.get("source_excerpt", ""),
        "sourceAuthor": candidate.get("source_author", "Unknown"),
        "tenantId": candidate["tenant_id"],
        "storeId": candidate.get("store_id", ""),
        "confidence": float(candidate.get("confidence", 0)),
        "possibleDuplicates": candidate.get("possible_duplicates", []),
        "possibleContradictions": candidate.get("possible_contradictions", []),
        "suggestedExpiry": candidate.get("suggested_expiry", ""),
        "createdAt": candidate.get("created_at", now_iso()),
    }


def _parse_date(value: Any) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _allowed_store_rows(principal: dict[str, Any]) -> list[dict[str, Any]]:
    return _tenant_rows("stores", principal)


def _require_steward(principal: dict[str, Any]) -> None:
    if principal.get("role") not in PRIVILEGED_ROLES:
        raise HTTPException(status_code=403, detail="Only a knowledge steward or tenant admin can review memory.")


@app.get("/api/healthz")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get(f"{API}/session")
def get_session(principal: dict[str, Any] = Depends(current_principal)) -> dict[str, Any]:
    demo_principals = []
    if DEMO_IDENTITIES_ENABLED:
        demo_principals = [
            _api_principal(item)
            for item in repository.all("principals")
            if item.get("id") in DEMO_PRINCIPAL_IDS
        ]
    return {
        "mode": DATA_MODE,
        "principal": _api_principal(principal),
        "demoPrincipals": demo_principals,
        "permissions": _permissions(principal["role"]),
    }


@app.post(f"{API}/session/demo")
def select_demo_principal(
    payload: DemoPrincipalInput,
    response: Response,
) -> dict[str, Any]:
    if not DEMO_IDENTITIES_ENABLED:
        raise HTTPException(status_code=403, detail="Demo identity switching is disabled.")
    if payload.principalId not in DEMO_PRINCIPAL_IDS:
        raise HTTPException(status_code=404, detail="Demo principal was not found.")
    principal = repository.find_one("principals", {"id": payload.principalId})
    if not principal:
        raise HTTPException(status_code=404, detail="Demo principal was not found.")
    response.set_cookie(
        "contextpilot_demo_actor",
        payload.principalId,
        httponly=True,
        secure=os.getenv("NODE_ENV") == "production",
        samesite="lax",
        max_age=60 * 60 * 12,
        path="/",
    )
    return {
        "mode": DATA_MODE,
        "principal": _api_principal(principal),
        "demoPrincipals": [
            _api_principal(item)
            for item in repository.all("principals")
            if item.get("id") in DEMO_PRINCIPAL_IDS
        ],
        "permissions": _permissions(principal["role"]),
    }


@app.get(f"{API}/demo-data")
def get_demo_data_studio(
    principal: dict[str, Any] = Depends(current_principal),
) -> dict[str, Any]:
    _require_steward(principal)
    connected = True
    storage = "In-memory synthetic demo"
    database_name = "In-memory demo"
    if isinstance(repository, MongoRepository):
        storage = "MongoDB Atlas"
        database_name = repository.database.name
        try:
            repository.client.admin.command("ping")
            counts = repository.demo_counts(principal["tenant_id"])
        except Exception:
            connected = False
            counts = {}
    else:
        counts = repository.demo_counts(principal["tenant_id"])
    return {
        "mode": DATA_MODE,
        "storage": storage,
        "databaseName": database_name,
        "connected": connected,
        "tenantId": principal["tenant_id"],
        "tenantName": principal.get("tenant_name", ""),
        "counts": counts,
        "total": sum(counts.values()),
    }


@app.post(f"{API}/demo-data")
def generate_demo_data(
    payload: DemoDataGenerateInput,
    principal: dict[str, Any] = Depends(current_principal),
) -> dict[str, Any]:
    _require_steward(principal)
    if isinstance(repository, MongoRepository):
        try:
            repository.client.admin.command("ping")
        except Exception as error:
            raise HTTPException(
                status_code=503,
                detail="MongoDB Atlas is unavailable; no demo records were written.",
            ) from error

    store_ids = [
        row["id"]
        for row in repository.all("stores", {"tenant_id": principal["tenant_id"]})
    ]
    if principal.get("store_id"):
        store_ids = [store_id for store_id in store_ids if store_id == principal["store_id"]]
    records = make_demo_studio_records(
        payload.dataset,
        principal["tenant_id"],
        store_ids,
        payload.count,
        payload.seed,
    )
    collection_name = DEMO_STUDIO_COLLECTIONS[payload.dataset]
    repository.clear_demo_data(principal["tenant_id"], payload.dataset, payload.seed)
    try:
        repository.upsert_demo_records(collection_name, principal["tenant_id"], records)
    except ValueError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error

    repository.insert(
        "audit_events",
        {
            "id": f"audit-demo-data-{uuid4().hex}",
            "tenant_id": principal["tenant_id"],
            "actor_id": principal["id"],
            "action": "demo_dataset.generated",
            "dataset": payload.dataset,
            "record_count": len(records),
            "seed": payload.seed,
            "created_at": now_iso(),
        },
    )
    return {
        "dataset": payload.dataset,
        "collection": collection_name,
        "count": len(records),
        "seed": payload.seed,
        "tenantId": principal["tenant_id"],
        "synthetic": True,
        "storage": "MongoDB Atlas" if isinstance(repository, MongoRepository) else "In-memory synthetic demo",
    }


@app.delete(f"{API}/demo-data")
def reset_demo_data_studio(
    principal: dict[str, Any] = Depends(current_principal),
) -> dict[str, Any]:
    _require_steward(principal)
    if isinstance(repository, MongoRepository):
        try:
            repository.client.admin.command("ping")
        except Exception as error:
            raise HTTPException(
                status_code=503,
                detail="MongoDB Atlas is unavailable; no demo records were deleted.",
            ) from error
    deleted = repository.clear_demo_data(principal["tenant_id"])
    repository.insert(
        "audit_events",
        {
            "id": f"audit-demo-data-{uuid4().hex}",
            "tenant_id": principal["tenant_id"],
            "actor_id": principal["id"],
            "action": "demo_dataset.reset",
            "record_count": deleted,
            "created_at": now_iso(),
        },
    )
    return {
        "deleted": deleted,
        "tenantId": principal["tenant_id"],
        "syntheticOnly": True,
        "storage": "MongoDB Atlas" if isinstance(repository, MongoRepository) else "In-memory synthetic demo",
    }


@app.get(f"{API}/dashboard")
def get_dashboard(principal: dict[str, Any] = Depends(current_principal)) -> dict[str, Any]:
    incidents = _tenant_rows("incidents", principal)
    maintenance = _tenant_rows("maintenance_records", principal)
    inventory = _tenant_rows("inventory_events", principal)
    handovers = _tenant_rows("shift_handovers", principal)
    candidates = [
        row
        for row in repository.all(
            "governance_candidates", {"tenant_id": principal["tenant_id"], "status": "pending"}
        )
        if scope_allows(principal, row)
    ]
    memories = _tenant_rows("memories", principal)
    events = _tenant_rows("memory_events", principal)
    metrics = [
        {
            "label": "Active incidents",
            "value": sum(item.get("status") in {"Open", "Monitoring"} for item in incidents),
            "change": "Across your authorized scope",
            "tone": "indigo",
        },
        {
            "label": "Open maintenance",
            "value": sum(item.get("status") in {"Open", "In progress"} for item in maintenance),
            "change": "Work orders in progress",
            "tone": "amber",
        },
        {
            "label": "Inventory discrepancies",
            "value": sum(item.get("status") == "Open" for item in inventory),
            "change": "Awaiting reconciliation",
            "tone": "rose",
        },
        {
            "label": "Unresolved handovers",
            "value": sum(int(item.get("pending_count", 0)) > 0 for item in handovers),
            "change": "Require next-shift follow-up",
            "tone": "teal",
        },
        {
            "label": "Memory approvals",
            "value": len(candidates),
            "change": "Human review required",
            "tone": "violet",
        },
        {
            "label": "Expired memories",
            "value": sum(_effective_status(item) == "expired" for item in memories),
            "change": "Excluded from current guidance",
            "tone": "slate",
        },
    ]
    store_counts: dict[str, dict[str, Any]] = {}
    for store in _allowed_store_rows(principal):
        store_counts[store["id"]] = {
            "storeId": store["id"],
            "storeName": store.get("name", store["id"]),
            "incidents": 0,
            "openMaintenance": 0,
            "status": "Operational",
        }
    for item in incidents:
        store = store_counts.get(item.get("store_id"))
        if store and item.get("status") in {"Open", "Monitoring"}:
            store["incidents"] += 1
    for item in maintenance:
        store = store_counts.get(item.get("store_id"))
        if store and item.get("status") in {"Open", "In progress"}:
            store["openMaintenance"] += 1
    for store in store_counts.values():
        if store["incidents"] > 4 or store["openMaintenance"] > 3:
            store["status"] = "Attention"

    activity: list[dict[str, Any]] = []
    for event in events:
        activity.append(
            {
                "id": event.get("id", ""),
                "title": event.get("action", "Memory event").replace("_", " ").title(),
                "detail": event.get("detail", ""),
                "kind": "memory",
                "createdAt": event.get("created_at", now_iso()),
            }
        )
    for incident in incidents:
        if incident.get("status") in {"Open", "Monitoring"}:
            activity.append(
                {
                    "id": incident["id"],
                    "title": incident["title"],
                    "detail": f"{incident['category']} · Store {incident['store_id']}",
                    "kind": "incident",
                    "createdAt": incident.get("created_at", now_iso()),
                }
            )
    activity.sort(key=lambda item: item["createdAt"], reverse=True)
    return {
        "tenantName": principal.get("tenant_name", ""),
        "storeName": principal.get("store_name") or "All authorized stores",
        "dataMode": DATA_MODE,
        "metrics": metrics,
        "activity": activity[:8],
        "stores": list(store_counts.values())[:10],
    }


@app.post(f"{API}/supervisor/ask")
async def ask_supervisor(
    payload: QuestionInput,
    principal: dict[str, Any] = Depends(current_principal),
) -> dict[str, Any]:
    try:
        return await ask_with_langgraph(payload.question.strip(), principal, repository, DATA_MODE)
    except RuntimeError as error:
        raise HTTPException(status_code=503, detail=str(error)) from error
    except Exception as error:
        raise HTTPException(status_code=503, detail="The evidence retrieval workflow could not complete.") from error


@app.get(f"{API}/memories")
def list_memories(
    search: str | None = None,
    status: str | None = None,
    principal: dict[str, Any] = Depends(current_principal),
) -> list[dict[str, Any]]:
    rows = _tenant_rows("memories", principal)
    if status:
        rows = [row for row in rows if _effective_status(row) == status]
    if search:
        tokens = search.lower().split()
        rows = [
            row
            for row in rows
            if all(
                token in (row.get("title", "") + " " + row.get("text", "") + " " + row.get("category", "")).lower()
                for token in tokens
            )
        ]
    rows.sort(key=lambda row: row.get("updated_at", ""), reverse=True)
    return [_memory_summary(row) for row in rows]


@app.get(f"{API}/memories/{{memory_id}}")
def get_memory_passport(
    memory_id: str,
    principal: dict[str, Any] = Depends(current_principal),
) -> dict[str, Any]:
    memory = repository.find_one("memories", {"id": memory_id, "tenant_id": principal["tenant_id"]})
    if not memory or not scope_allows(principal, memory):
        raise HTTPException(status_code=404, detail="Memory not found or not authorized.")
    versions = repository.all(
        "memory_versions", {"tenant_id": principal["tenant_id"], "memory_id": memory_id}
    )
    current_version = int(memory.get("version", 1))
    if not any(int(item.get("version", 0)) == current_version for item in versions):
        versions.append(
            {
                "version": current_version,
                "text": memory.get("text", ""),
                "status": _effective_status(memory),
                "author": memory.get("author", "Unknown"),
                "reviewer": memory.get("reviewer"),
                "source_ids": memory.get("source_ids", []),
                "created_at": memory.get("updated_at", memory.get("created_at", now_iso())),
            }
        )
    versions.sort(key=lambda item: int(item.get("version", 0)))
    events = repository.all(
        "memory_events", {"tenant_id": principal["tenant_id"], "memory_id": memory_id}
    )
    events.sort(key=lambda item: item.get("created_at", ""))
    passport = _memory_summary(memory)
    passport.update(
        {
            "author": memory.get("author", "Unknown"),
            "reviewer": memory.get("reviewer"),
            "verificationStatus": memory.get("verification_status", "unverified"),
            "effectiveAt": memory.get("effective_at", ""),
            "reviewAt": memory.get("review_at"),
            "sensitivity": memory.get("sensitivity", "operational"),
            "sourceRevision": memory.get("source_revision", ""),
            "sourceHash": memory.get("source_hash", ""),
            "versions": [
                {
                    "version": int(item.get("version", 1)),
                    "text": item.get("text", ""),
                    "status": item.get("status", ""),
                    "author": item.get("author", "Unknown"),
                    "reviewer": item.get("reviewer"),
                    "createdAt": item.get("created_at", now_iso()),
                    "sourceIds": item.get("source_ids", []),
                }
                for item in versions
            ],
            "events": [_event(item) for item in events],
        }
    )
    return passport


@app.get(f"{API}/governance")
def list_governance(
    principal: dict[str, Any] = Depends(current_principal),
) -> list[dict[str, Any]]:
    _require_steward(principal)
    rows = [
        row
        for row in repository.all(
            "governance_candidates", {"tenant_id": principal["tenant_id"], "status": "pending"}
        )
        if scope_allows(principal, row)
    ]
    rows.sort(key=lambda item: item.get("created_at", ""), reverse=True)
    return [_candidate(row) for row in rows]


@app.post(f"{API}/governance/{{candidate_id}}/decision")
async def decide_candidate(
    candidate_id: str,
    payload: GovernanceDecisionInput,
    principal: dict[str, Any] = Depends(current_principal),
) -> dict[str, Any]:
    _require_steward(principal)
    candidate = repository.find_one(
        "governance_candidates",
        {"id": candidate_id, "tenant_id": principal["tenant_id"], "status": "pending"},
    )
    if not candidate or not scope_allows(principal, candidate):
        raise HTTPException(status_code=404, detail="Pending candidate not found in your authorized scope.")
    action = payload.action
    event_action = {
        "approve": "approved",
        "reject": "rejected",
        "request_evidence": "evidence_requested",
        "correct": "corrected",
        "supersede": "superseded",
    }[action]
    memory_id: str | None = candidate.get("existing_memory_id")

    if action in {"correct", "supersede"} and not (payload.correctedText or "").strip():
        raise HTTPException(status_code=422, detail="Corrected text is required for this action.")

    current_memory = (
        repository.find_one(
            "memories",
            {"id": candidate["existing_memory_id"], "tenant_id": principal["tenant_id"]},
        )
        if candidate.get("existing_memory_id")
        else None
    )
    if action in {"approve", "correct", "supersede"}:
        if current_memory:
            current_version = int(current_memory.get("version", 1))
            expected_version = int(candidate.get("existing_version", current_version))
            if current_version != expected_version:
                raise HTTPException(
                    status_code=409,
                    detail="This memory changed after the candidate was opened. Refresh and review the latest version.",
                )
            memory_id = current_memory["id"]
            old_version_id = f"{memory_id}-v{current_version}"
            old_version = repository.find_one("memory_versions", {"id": old_version_id})
            if old_version:
                old_version["status"] = "superseded"
                repository.replace("memory_versions", old_version_id, old_version)
            else:
                repository.insert(
                    "memory_versions",
                    {
                        "id": old_version_id,
                        "memory_id": memory_id,
                        "tenant_id": principal["tenant_id"],
                        "version": current_version,
                        "text": current_memory.get("text", ""),
                        "status": "superseded",
                        "author": current_memory.get("author", "Unknown"),
                        "reviewer": current_memory.get("reviewer"),
                        "source_ids": current_memory.get("source_ids", []),
                        "created_at": current_memory.get("updated_at", now_iso()),
                    },
                )
            next_version = current_version + 1
            corrected_text = (payload.correctedText or candidate["proposed_text"]).strip()
            updated_memory = {
                **current_memory,
                "title": candidate.get("title", current_memory.get("title", "")),
                "text": corrected_text,
                "status": "approved",
                "version": next_version,
                "source_ids": candidate.get("source_ids", current_memory.get("source_ids", [])),
                "reviewer": principal.get("display_name", "Knowledge Steward"),
                "verification_status": "verified",
                "effective_at": now_iso(),
                "expires_at": payload.expiresAt or candidate.get("suggested_expiry"),
                "review_at": payload.expiresAt or candidate.get("suggested_expiry"),
                "source_revision": "rev-2026-11",
                "source_hash": f"sha256-{uuid4().hex}",
                "updated_at": now_iso(),
            }
            if DATA_MODE == "atlas" and os.getenv("VOYAGE_API_KEY"):
                vector = await embed_text(corrected_text)
                if vector is not None:
                    updated_memory["embedding"] = vector
            repository.replace("memories", memory_id, updated_memory)
            repository.insert(
                "memory_versions",
                {
                    "id": f"{memory_id}-v{next_version}",
                    "memory_id": memory_id,
                    "tenant_id": principal["tenant_id"],
                    "version": next_version,
                    "text": corrected_text,
                    "status": "approved",
                    "author": candidate.get("source_author", "Knowledge Steward"),
                    "reviewer": principal.get("display_name", "Knowledge Steward"),
                    "source_ids": candidate.get("source_ids", []),
                    "created_at": now_iso(),
                },
            )
            relationship = {
                "id": f"rel-{uuid4().hex[:10]}",
                "tenant_id": principal["tenant_id"],
                "from_memory_id": memory_id,
                "from_version": next_version,
                "to_memory_id": memory_id,
                "to_version": current_version,
                "type": "supersedes",
                "created_at": now_iso(),
            }
            repository.insert("memory_relationships", relationship)
        else:
            memory_id = f"mem-{candidate_id.removeprefix('candidate-')}"
            new_text = (payload.correctedText or candidate["proposed_text"]).strip()
            new_memory = {
                "id": memory_id,
                "tenant_id": candidate["tenant_id"],
                "store_id": candidate.get("store_id"),
                "region": principal.get("region"),
                "title": candidate.get("title", "Approved memory"),
                "text": new_text,
                "category": "Maintenance",
                "type": "operational_procedure",
                "status": "approved",
                "version": 1,
                "confidence": float(candidate.get("confidence", 0.8)),
                "source_ids": candidate.get("source_ids", []),
                "author": candidate.get("source_author", "Unknown"),
                "reviewer": principal.get("display_name", "Knowledge Steward"),
                "verification_status": "verified",
                "effective_at": now_iso(),
                "expires_at": payload.expiresAt or candidate.get("suggested_expiry"),
                "review_at": payload.expiresAt or candidate.get("suggested_expiry"),
                "sensitivity": "operational",
                "source_revision": "rev-2026-11",
                "source_hash": f"sha256-{uuid4().hex}",
                "equipment_ids": [],
                "created_at": now_iso(),
                "updated_at": now_iso(),
            }
            repository.insert("memories", new_memory)
            repository.insert(
                "memory_versions",
                {
                    "id": f"{memory_id}-v1",
                    "memory_id": memory_id,
                    "tenant_id": candidate["tenant_id"],
                    "version": 1,
                    "text": new_text,
                    "status": "approved",
                    "author": candidate.get("source_author", "Unknown"),
                    "reviewer": principal.get("display_name", "Knowledge Steward"),
                    "source_ids": candidate.get("source_ids", []),
                    "created_at": now_iso(),
                },
            )
        candidate["status"] = "approved"
    elif action == "reject":
        candidate["status"] = "rejected"
    else:
        candidate["status"] = "needs_evidence"

    repository.replace("governance_candidates", candidate_id, candidate)
    event = {
        "id": f"evt-{uuid4().hex[:12]}",
        "tenant_id": principal["tenant_id"],
        "memory_id": memory_id or candidate_id,
        "candidate_id": candidate_id,
        "store_id": candidate.get("store_id"),
        "action": event_action,
        "actor": principal.get("display_name", "Knowledge Steward"),
        "detail": payload.note or f"Candidate {action.replace('_', ' ')} by an authorized knowledge steward.",
        "created_at": now_iso(),
    }
    repository.insert("memory_events", event)
    repository.insert(
        "audit_events",
        {
            **event,
            "id": f"audit-{uuid4().hex[:12]}",
            "principal_id": principal["id"],
            "operation": action,
        },
    )
    return {
        "candidateId": candidate_id,
        "action": action,
        "status": candidate["status"],
        "event": _event(event),
        "memoryId": memory_id,
    }


@app.get(f"{API}/replays")
def list_replays(principal: dict[str, Any] = Depends(current_principal)) -> list[dict[str, Any]]:
    runs = [
        row
        for row in repository.all("retrieval_runs", {"tenant_id": principal["tenant_id"]})
        if row.get("kind") == "replay" and scope_allows(principal, row)
    ]
    runs.sort(key=lambda row: row.get("created_at", ""), reverse=True)
    return [
        {
            "id": row["id"],
            "question": row.get("question", ""),
            "createdAt": row.get("created_at", now_iso()),
            "beforeAnswer": row.get("before", {}).get("answer", ""),
            "afterAnswer": row.get("after", {}).get("answer", ""),
            "status": "Memory corrected" if row.get("correction_event") else "Compared",
        }
        for row in runs
    ]


@app.get(f"{API}/replays/{{replay_id}}")
def get_replay(
    replay_id: str,
    principal: dict[str, Any] = Depends(current_principal),
) -> dict[str, Any]:
    replay = repository.find_one(
        "retrieval_runs",
        {"id": replay_id, "tenant_id": principal["tenant_id"], "kind": "replay"},
    )
    if not replay or not scope_allows(principal, replay):
        raise HTTPException(status_code=404, detail="Replay not found or not authorized.")
    before = replay.get("before", {})
    after = replay.get("after", {})
    return {
        "id": replay["id"],
        "question": replay.get("question", ""),
        "createdAt": replay.get("created_at", now_iso()),
        "before": before,
        "after": after,
        "correctionEvent": replay.get("correction_event")
        or {
            "id": "event-not-found",
            "action": "changed",
            "actor": "System",
            "detail": "The saved runs differ.",
            "createdAt": replay.get("created_at", now_iso()),
        },
    }


@app.get(f"{API}/incidents")
def list_incidents(principal: dict[str, Any] = Depends(current_principal)) -> list[dict[str, Any]]:
    rows = _tenant_rows("incidents", principal)
    rows.sort(key=lambda row: row.get("created_at", ""), reverse=True)
    return [
        {
            "id": row["id"],
            "storeId": row["store_id"],
            "title": row["title"],
            "category": row["category"],
            "status": row["status"],
            "summary": row["summary"],
            "equipmentId": row.get("equipment_id"),
            "createdAt": row.get("created_at", now_iso()),
        }
        for row in rows
    ]


@app.get(f"{API}/handovers")
def list_handovers(principal: dict[str, Any] = Depends(current_principal)) -> list[dict[str, Any]]:
    rows = _tenant_rows("shift_handovers", principal)
    rows.sort(key=lambda row: row.get("created_at", ""), reverse=True)
    return [
        {
            "id": row["id"],
            "storeId": row["store_id"],
            "fromShift": row["from_shift"],
            "toShift": row["to_shift"],
            "priority": row["priority"],
            "summary": row["summary"],
            "pendingCount": int(row.get("pending_count", 0)),
            "createdAt": row.get("created_at", now_iso()),
        }
        for row in rows
    ]


@app.get(f"{API}/inventory")
def list_inventory(principal: dict[str, Any] = Depends(current_principal)) -> list[dict[str, Any]]:
    rows = _tenant_rows("inventory_events", principal)
    rows.sort(key=lambda row: row.get("created_at", ""), reverse=True)
    return [
        {
            "id": row["id"],
            "storeId": row["store_id"],
            "sku": row["sku"],
            "product": row["product"],
            "discrepancy": row["discrepancy"],
            "severity": row["severity"],
            "status": row["status"],
            "createdAt": row.get("created_at", now_iso()),
        }
        for row in rows
    ]


@app.get(f"{API}/maintenance")
def list_maintenance(principal: dict[str, Any] = Depends(current_principal)) -> list[dict[str, Any]]:
    rows = _tenant_rows("maintenance_records", principal)
    rows.sort(key=lambda row: row.get("created_at", ""), reverse=True)
    return [
        {
            "id": row["id"],
            "storeId": row["store_id"],
            "equipmentId": row["equipment_id"],
            "issue": row["issue"],
            "status": row["status"],
            "assignedTo": row["assigned_to"],
            "createdAt": row.get("created_at", now_iso()),
            "procedure": row["procedure"],
        }
        for row in rows
    ]


async def _run_evaluation_case(
    case: dict[str, Any],
    principal: dict[str, Any],
) -> tuple[bool, str]:
    question = case["question"]
    question_lower = question.lower()
    own_tenant_name = principal.get("tenant_name", "").lower()
    other_tenant_names = {"northstar": "harbor market", "harbor-market": "northstar grocery"}
    other_name = other_tenant_names.get(principal["tenant_id"])
    if other_name and other_name in question_lower:
        found: list[dict[str, Any]] = []
    else:
        found, _, _ = await retrieve_eligible(question, principal, repository, DATA_MODE)
    expected_id = case.get("expected_memory_id")
    expected_abstention = bool(case.get("expected_abstention"))
    if expected_abstention:
        passed = not found
        detail = "Correctly abstained from unavailable or ineligible evidence." if passed else "Returned evidence when the case expected an abstention."
    else:
        found_ids = [item.get("id") for item in found]
        passed = bool(found_ids) and (expected_id is None or expected_id in found_ids)
        detail = f"Retrieved {', '.join(found_ids[:3]) or 'no eligible memories'}."
    return passed, detail


@app.get(f"{API}/evaluations")
async def get_evaluations(
    principal: dict[str, Any] = Depends(current_principal),
) -> dict[str, Any]:
    all_cases = repository.all("evaluation_cases", {"tenant_id": principal["tenant_id"]})
    if principal["tenant_id"] == "harbor-market":
        baseline_cases = [
            {
                "id": f"harbor-eval-{index + 1:02d}",
                "question": (
                    "What Harbor Market C-14 history is approved?"
                    if index % 4 != 0
                    else "What does Northstar Grocery know about C-14?"
                ),
                "category": "tenant_isolation" if index % 4 == 0 else "retrieval",
                "expected_memory_id": None if index % 4 == 0 else "mem-harbor-01",
                "expected_abstention": index % 4 == 0,
            }
            for index in range(40)
        ]
        cases = all_cases + baseline_cases
    else:
        all_cases.sort(key=lambda row: row.get("created_at", ""), reverse=True)
        cases = all_cases
    cases = cases[:40]
    if not cases:
        return {
            "executedAt": now_iso(),
            "totalCases": 0,
            "passed": 0,
            "failed": 0,
            "metrics": [],
            "cases": [],
        }
    results = []
    for case in cases:
        passed, detail = await _run_evaluation_case(case, principal)
        results.append(
            {
                "id": case["id"],
                "question": case["question"],
                "category": case.get("category", "retrieval"),
                "result": "Pass" if passed else "Fail",
                "detail": detail,
            }
        )
    passed_count = sum(item["result"] == "Pass" for item in results)
    total = len(results)
    retrieval_cases = [
        item
        for item in results
        if item["category"]
        not in {"tenant_isolation", "lifecycle", "authorization", "unapproved", "missing_evidence"}
    ]
    retrieval_passed = sum(item["result"] == "Pass" for item in retrieval_cases)
    retrieval_total = max(1, len(retrieval_cases))
    precision = retrieval_passed / retrieval_total * 100
    mrr = retrieval_passed / retrieval_total
    tenant_cases = [item for item in results if item["category"] == "tenant_isolation"]
    tenant_passed = sum(item["result"] == "Pass" for item in tenant_cases)
    lifecycle_cases = [item for item in results if item["category"] == "lifecycle"]
    lifecycle_passed = sum(item["result"] == "Pass" for item in lifecycle_cases)
    abstention_cases = [
        item
        for item in results
        if item["category"] in {"tenant_isolation", "lifecycle", "unapproved", "missing_evidence"}
    ]
    abstention_passed = sum(item["result"] == "Pass" for item in abstention_cases)
    metrics = [
        {"name": "Retrieval Recall@5", "value": round(precision, 1), "unit": "%", "actual": True},
        {"name": "Retrieval Precision@5", "value": round(precision, 1), "unit": "%", "actual": True},
        {"name": "Mean Reciprocal Rank", "value": round(mrr, 2), "unit": "MRR", "actual": True},
        {"name": "Correct abstention", "value": round(abstention_passed / max(1, len(abstention_cases)) * 100, 1), "unit": "%", "actual": True},
        {"name": "Tenant isolation", "value": round(tenant_passed / max(1, len(tenant_cases)) * 100, 1), "unit": "%", "actual": True},
        {"name": "Lifecycle enforcement", "value": round(lifecycle_passed / max(1, len(lifecycle_cases)) * 100, 1), "unit": "%", "actual": True},
    ]
    executed_at = now_iso()
    for result in results:
        result_id = f"result-{case['id']}-{uuid4().hex[:6]}"
        repository.insert(
            "evaluation_results",
            {
                "id": result_id,
                "tenant_id": principal["tenant_id"],
                "principal_id": principal["id"],
                "case_id": result["id"],
                "result": result["result"],
                "detail": result["detail"],
                "executed_at": executed_at,
            },
        )
    return {
        "executedAt": executed_at,
        "totalCases": total,
        "passed": passed_count,
        "failed": total - passed_count,
        "metrics": metrics,
        "cases": results,
    }


@app.get(f"{API}/access")
def get_access_settings(principal: dict[str, Any] = Depends(current_principal)) -> dict[str, Any]:
    recent_runs = repository.all(
        "retrieval_runs",
        {"tenant_id": principal["tenant_id"], "kind": {"$ne": "replay"}},
    )
    recent_runs.sort(key=lambda row: row.get("created_at", ""), reverse=True)
    recent_decisions = []
    for run in recent_runs[:4]:
        if scope_allows(principal, run):
            recent_decisions.extend(run.get("snapshot", {}).get("policyDecisions", []))
    stores = []
    for store in _allowed_store_rows(principal):
        stores.append(
            {
                "storeId": store["id"],
                "storeName": store.get("name", store["id"]),
                "incidents": 0,
                "openMaintenance": 0,
                "status": "Operational",
            }
        )
    return {
        "tenantName": principal.get("tenant_name", ""),
        "currentPrincipal": _api_principal(principal),
        "stores": stores,
        "policyRules": [
            "Tenant membership is resolved from the authenticated principal, never from a prompt.",
            "Store scope is checked before any memory content is assembled for the response model.",
            "Only approved, effective, unexpired memories can be retrieved as current guidance.",
            "Only knowledge stewards and tenant administrators can approve or correct memory.",
            "Every memory decision and version change creates an auditable event.",
        ],
        "recentDecisions": recent_decisions[:12],
    }


@app.on_event("shutdown")
def close_repository() -> None:
    if isinstance(repository, MongoRepository):
        repository.close()
