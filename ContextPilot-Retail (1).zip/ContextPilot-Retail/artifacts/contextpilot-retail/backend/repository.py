from __future__ import annotations

import json
import os
from copy import deepcopy
from pathlib import Path
from typing import Any

from pymongo import ASCENDING, MongoClient
from pymongo.operations import SearchIndexModel

from .demo_seed import DEMO_STUDIO_COLLECTIONS, make_demo_data, make_demo_studio_records


COLLECTIONS = [
    "tenants",
    "stores",
    "principals",
    "employees",
    "source_documents",
    "source_revisions",
    "incidents",
    "inventory_events",
    "shift_handovers",
    "maintenance_records",
    "memories",
    "memory_versions",
    "memory_events",
    "memory_relationships",
    "retrieval_runs",
    "agent_runs",
    "evaluation_cases",
    "evaluation_results",
    "audit_events",
    "governance_candidates",
]


class MemoryRepository:
    def __init__(self) -> None:
        self.collections = make_demo_data()
        for name in COLLECTIONS:
            self.collections.setdefault(name, [])
        tenant_ids = sorted({store["tenant_id"] for store in self.collections["stores"]})
        for tenant_id in tenant_ids:
            store_ids = [
                store["id"]
                for store in self.collections["stores"]
                if store["tenant_id"] == tenant_id
            ]
            for dataset, collection_name in DEMO_STUDIO_COLLECTIONS.items():
                records = make_demo_studio_records(
                    dataset=dataset,
                    tenant_id=tenant_id,
                    store_ids=store_ids,
                    count=8,
                    seed=41014,
                )
                self.upsert_demo_records(collection_name, tenant_id, records)

    def all(self, name: str, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        rows = self.collections.get(name, [])
        if not query:
            return deepcopy(rows)
        return deepcopy([row for row in rows if _matches(row, query)])

    def find_one(self, name: str, query: dict[str, Any]) -> dict[str, Any] | None:
        for row in self.collections.get(name, []):
            if _matches(row, query):
                return deepcopy(row)
        return None

    def insert(self, name: str, document: dict[str, Any]) -> None:
        target = self.collections.setdefault(name, [])
        if any(row.get("id") == document.get("id") for row in target):
            raise ValueError(f"Duplicate id in {name}: {document.get('id')}")
        target.append(deepcopy(document))

    def replace(self, name: str, document_id: str, document: dict[str, Any]) -> None:
        target = self.collections.setdefault(name, [])
        for index, row in enumerate(target):
            if row.get("id") == document_id:
                target[index] = deepcopy(document)
                return
        target.append(deepcopy(document))

    def update(self, name: str, document_id: str, changes: dict[str, Any]) -> dict[str, Any] | None:
        target = self.collections.setdefault(name, [])
        for row in target:
            if row.get("id") == document_id:
                row.update(deepcopy(changes))
                return deepcopy(row)
        return None

    def demo_counts(self, tenant_id: str) -> dict[str, int]:
        return {
            dataset: sum(
                row.get("tenant_id") == tenant_id and row.get("demo_dataset") is True
                for row in self.collections.get(collection_name, [])
            )
            for dataset, collection_name in DEMO_STUDIO_COLLECTIONS.items()
        }

    def clear_demo_data(
        self,
        tenant_id: str,
        dataset: str | None = None,
        seed: int | None = None,
    ) -> int:
        collections = (
            {DEMO_STUDIO_COLLECTIONS[dataset]}
            if dataset
            else set(DEMO_STUDIO_COLLECTIONS.values())
        )
        deleted = 0
        for name in collections:
            rows = self.collections.setdefault(name, [])
            kept = []
            for row in rows:
                matches = (
                    row.get("tenant_id") == tenant_id
                    and row.get("demo_dataset") is True
                    and (dataset is None or row.get("demo_dataset_type") == dataset)
                    and (seed is None or row.get("demo_seed") == seed)
                )
                if matches:
                    deleted += 1
                else:
                    kept.append(row)
            self.collections[name] = kept
        return deleted

    def upsert_demo_records(
        self,
        collection_name: str,
        tenant_id: str,
        documents: list[dict[str, Any]],
    ) -> None:
        if collection_name not in set(DEMO_STUDIO_COLLECTIONS.values()):
            raise ValueError("The target collection is not enabled for synthetic demo data.")
        target = self.collections.setdefault(collection_name, [])
        for document in documents:
            if document.get("tenant_id") != tenant_id or document.get("demo_dataset") is not True:
                raise ValueError("Demo records must be marked synthetic and scoped to the active tenant.")
            existing = next((row for row in target if row.get("id") == document.get("id")), None)
            if existing and existing.get("demo_dataset") is not True:
                raise ValueError("A synthetic record ID conflicts with a non-synthetic record.")
            self.replace(collection_name, document["id"], document)


class MongoRepository:
    def __init__(self, uri: str, database_name: str) -> None:
        self.client = MongoClient(uri, serverSelectionTimeoutMS=7000, connectTimeoutMS=7000)
        self.client.admin.command("ping")
        self.database = self.client[database_name]
        self.create_indexes()

    def create_indexes(self) -> None:
        self.database["memories"].create_index(
            [("tenant_id", ASCENDING), ("store_id", ASCENDING), ("status", ASCENDING)]
        )
        self.database["memories"].create_index(
            [("tenant_id", ASCENDING), ("category", ASCENDING), ("updated_at", ASCENDING)]
        )
        self.database["memories"].create_index([("source_ids", ASCENDING)])
        self.database["memory_versions"].create_index(
            [("tenant_id", ASCENDING), ("memory_id", ASCENDING), ("version", ASCENDING)],
            unique=True,
        )
        self.database["memory_events"].create_index(
            [("tenant_id", ASCENDING), ("memory_id", ASCENDING), ("created_at", ASCENDING)]
        )
        self.database["retrieval_runs"].create_index(
            [("tenant_id", ASCENDING), ("store_id", ASCENDING), ("question_key", ASCENDING), ("created_at", ASCENDING)]
        )
        self.database["incidents"].create_index(
            [("tenant_id", ASCENDING), ("store_id", ASCENDING), ("created_at", ASCENDING)]
        )
        self.database["shift_handovers"].create_index(
            [("tenant_id", ASCENDING), ("store_id", ASCENDING), ("created_at", ASCENDING)]
        )
        self.database["inventory_events"].create_index(
            [("tenant_id", ASCENDING), ("store_id", ASCENDING), ("status", ASCENDING)]
        )
        self.database["maintenance_records"].create_index(
            [("tenant_id", ASCENDING), ("store_id", ASCENDING), ("equipment_id", ASCENDING)]
        )
        self.database["principals"].create_index(
            [("tenant_id", ASCENDING), ("clerk_user_id", ASCENDING)]
        )
        self.database["audit_events"].create_index(
            [("tenant_id", ASCENDING), ("created_at", ASCENDING)]
        )
        self.database["governance_candidates"].create_index(
            [("tenant_id", ASCENDING), ("store_id", ASCENDING), ("status", ASCENDING)]
        )
        for collection_name in set(DEMO_STUDIO_COLLECTIONS.values()):
            self.database[collection_name].create_index(
                [
                    ("tenant_id", ASCENDING),
                    ("demo_dataset", ASCENDING),
                    ("demo_dataset_type", ASCENDING),
                    ("demo_seed", ASCENDING),
                ],
                name="demo_studio_scope",
            )

    def ensure_vector_search_index(self, index_name: str) -> str:
        config_path = Path(__file__).with_name("atlas_vector_index.json")
        config = json.loads(config_path.read_text(encoding="utf-8"))
        definition = config["definition"]
        collection = self.database["memories"]

        try:
            existing = next(
                (
                    item
                    for item in collection.list_search_indexes()
                    if item.get("name") == index_name
                ),
                None,
            )
        except Exception as error:
            raise RuntimeError(
                "Could not inspect Atlas Vector Search indexes. "
                "Confirm this database user can list and create Search indexes."
            ) from error

        if existing:
            existing_definition = (
                existing.get("latestDefinition")
                or existing.get("definition")
                or {}
            )
            if existing_definition.get("fields") != definition.get("fields"):
                raise RuntimeError(
                    f"Atlas index '{index_name}' exists with a different definition. "
                    "Review backend/atlas_vector_index.json and update the index in Atlas; "
                    "the seeder will not replace or delete an existing index."
                )
            return "existing"

        model = SearchIndexModel(
            name=index_name,
            type="vectorSearch",
            definition=definition,
        )
        try:
            collection.create_search_index(model=model)
        except Exception as error:
            raise RuntimeError(
                f"Could not create Atlas Vector Search index '{index_name}'. "
                "Confirm Atlas Search is available and the database user can create indexes."
            ) from error
        return "created"

    def all(self, name: str, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        return [_clean_doc(row) for row in self.database[name].find(query or {})]

    def find_one(self, name: str, query: dict[str, Any]) -> dict[str, Any] | None:
        row = self.database[name].find_one(query)
        return _clean_doc(row) if row else None

    def insert(self, name: str, document: dict[str, Any]) -> None:
        self.database[name].insert_one(deepcopy(document))

    def replace(self, name: str, document_id: str, document: dict[str, Any]) -> None:
        self.database[name].replace_one({"id": document_id}, deepcopy(document), upsert=True)

    def update(self, name: str, document_id: str, changes: dict[str, Any]) -> dict[str, Any] | None:
        self.database[name].update_one({"id": document_id}, {"$set": deepcopy(changes)})
        return self.find_one(name, {"id": document_id})

    def demo_counts(self, tenant_id: str) -> dict[str, int]:
        return {
            dataset: self.database[collection_name].count_documents(
                {"tenant_id": tenant_id, "demo_dataset": True}
            )
            for dataset, collection_name in DEMO_STUDIO_COLLECTIONS.items()
        }

    def clear_demo_data(
        self,
        tenant_id: str,
        dataset: str | None = None,
        seed: int | None = None,
    ) -> int:
        collections = (
            {DEMO_STUDIO_COLLECTIONS[dataset]}
            if dataset
            else set(DEMO_STUDIO_COLLECTIONS.values())
        )
        query: dict[str, Any] = {"tenant_id": tenant_id, "demo_dataset": True}
        if dataset:
            query["demo_dataset_type"] = dataset
        if seed is not None:
            query["demo_seed"] = seed
        return sum(
            self.database[collection_name].delete_many(query).deleted_count
            for collection_name in collections
        )

    def upsert_demo_records(
        self,
        collection_name: str,
        tenant_id: str,
        documents: list[dict[str, Any]],
    ) -> None:
        if collection_name not in set(DEMO_STUDIO_COLLECTIONS.values()):
            raise ValueError("The target collection is not enabled for synthetic demo data.")
        collection = self.database[collection_name]
        for document in documents:
            if document.get("tenant_id") != tenant_id or document.get("demo_dataset") is not True:
                raise ValueError("Demo records must be marked synthetic and scoped to the active tenant.")
            selector = {"id": document["id"], "tenant_id": tenant_id}
            existing = collection.find_one(selector, {"demo_dataset": 1})
            if existing and existing.get("demo_dataset") is not True:
                raise ValueError("A synthetic record ID conflicts with a non-synthetic record.")
            collection.replace_one(selector, deepcopy(document), upsert=True)

    def vector_search(
        self,
        vector: list[float],
        tenant_id: str,
        store_id: str | None,
        index_name: str,
        limit: int = 8,
    ) -> list[dict[str, Any]]:
        prefilter: dict[str, Any] = {
            "tenant_id": {"$eq": tenant_id},
            "status": {"$eq": "approved"},
        }
        if store_id:
            prefilter["store_id"] = {"$eq": store_id}
        pipeline = [
            {
                "$vectorSearch": {
                    "index": index_name,
                    "path": "embedding",
                    "queryVector": vector,
                    "numCandidates": max(limit * 10, 100),
                    "limit": limit,
                    "filter": prefilter,
                }
            },
            {"$addFields": {"vector_score": {"$meta": "vectorSearchScore"}}},
        ]
        return [_clean_doc(row) for row in self.database["memories"].aggregate(pipeline)]

    def atlas_text_search(
        self,
        query_text: str,
        tenant_id: str,
        store_id: str | None,
        index_name: str,
        limit: int = 12,
    ) -> list[dict[str, Any]]:
        filters: list[dict[str, Any]] = [
            {"equals": {"path": "tenant_id", "value": tenant_id}},
            {"equals": {"path": "status", "value": "approved"}},
        ]
        if store_id:
            filters.append({"equals": {"path": "store_id", "value": store_id}})
        pipeline = [
            {
                "$search": {
                    "index": index_name,
                    "compound": {
                        "must": [
                            {
                                "text": {
                                    "query": query_text,
                                    "path": ["title", "text", "equipment_ids"],
                                }
                            }
                        ],
                        "filter": filters,
                    },
                }
            },
            {"$limit": limit},
        ]
        return [_clean_doc(row) for row in self.database["memories"].aggregate(pipeline)]

    def close(self) -> None:
        self.client.close()


def create_repository() -> tuple[MemoryRepository | MongoRepository, str]:
    uri = os.getenv("MONGODB_URI", "").strip()
    if not uri:
        return MemoryRepository(), "demo"
    database_name = os.getenv("MONGODB_DATABASE", "contextpilot_retail").strip()
    return MongoRepository(uri, database_name), "atlas"


def _clean_doc(document: dict[str, Any]) -> dict[str, Any]:
    result = dict(document)
    result.pop("_id", None)
    return result


def _matches(row: dict[str, Any], query: dict[str, Any]) -> bool:
    for key, expected in query.items():
        value = row.get(key)
        if isinstance(expected, dict):
            if "$in" in expected and value not in expected["$in"]:
                return False
            if "$ne" in expected and value == expected["$ne"]:
                return False
            if "$eq" in expected and value != expected["$eq"]:
                return False
        elif value != expected:
            return False
    return True
