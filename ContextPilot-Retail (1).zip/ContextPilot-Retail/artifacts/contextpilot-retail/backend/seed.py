from __future__ import annotations

import asyncio
import os
from typing import Any

import httpx

from .demo_seed import DEMO_STUDIO_COLLECTIONS, make_demo_data, make_demo_studio_records
from .repository import MongoRepository


async def _embed_documents(documents: list[dict[str, Any]]) -> list[list[float]]:
    api_key = os.getenv("VOYAGE_API_KEY", "").strip()
    if not api_key:
        raise SystemExit(
            "VOYAGE_API_KEY is required before seeding. "
            "Add the Voyage key to backend Secrets; no records were written."
        )
    payload = {
        "input": [f"{doc.get('title', '')}\n{doc.get('text', '')}" for doc in documents],
        "model": os.getenv("VOYAGE_MODEL", "voyage-3.5"),
        "input_type": "document",
    }
    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(
            "https://api.voyageai.com/v1/embeddings",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=payload,
        )
        response.raise_for_status()
        body = response.json()
        vectors = [row["embedding"] for row in body.get("data", [])]
        if len(vectors) != len(documents):
            raise RuntimeError(
                "Voyage returned a different number of vectors than memories. "
                "No records were written."
            )
        if any(not isinstance(vector, list) or len(vector) != 1024 for vector in vectors):
            raise RuntimeError(
                "Voyage returned a vector with an unexpected size. "
                "The Atlas index requires 1024 dimensions; no records were written."
            )
        return [[float(value) for value in vector] for vector in vectors]


async def seed() -> None:
    uri = os.getenv("MONGODB_URI", "").strip()
    if not uri:
        raise SystemExit("MONGODB_URI is required. Add it in Replit Secrets before seeding Atlas.")
    if not os.getenv("VOYAGE_API_KEY", "").strip():
        raise SystemExit(
            "VOYAGE_API_KEY is required before seeding. "
            "Add the Voyage key to backend Secrets; no records were written."
        )

    database_name = os.getenv("MONGODB_DATABASE", "contextpilot_retail").strip()
    datasets = make_demo_data()
    for tenant_id in sorted({store["tenant_id"] for store in datasets["stores"]}):
        store_ids = [
            store["id"]
            for store in datasets["stores"]
            if store["tenant_id"] == tenant_id
        ]
        for dataset, collection_name in DEMO_STUDIO_COLLECTIONS.items():
            datasets.setdefault(collection_name, []).extend(
                make_demo_studio_records(
                    dataset=dataset,
                    tenant_id=tenant_id,
                    store_ids=store_ids,
                    count=8,
                    seed=41014,
                )
            )
    memories = datasets["memories"]
    vectors = await _embed_documents(memories)
    for memory, vector in zip(memories, vectors, strict=True):
        memory["embedding"] = vector

    repository = MongoRepository(uri, database_name)
    try:
        index_name = os.getenv("ATLAS_VECTOR_INDEX", "memory_vector").strip()
        index_state = repository.ensure_vector_search_index(index_name)
        database = repository.database
        inserted = 0
        for collection_name, documents in datasets.items():
            if not documents:
                continue
            collection = database[collection_name]
            for document in documents:
                result = collection.update_one(
                    {"id": document["id"]},
                    {"$setOnInsert": document},
                    upsert=True,
                )
                inserted += int(result.upserted_id is not None)
        print(f"Seed finished. Added {inserted} new fictional records to {database_name}.")
        print(
            f"Atlas Vector Search index '{index_name}': {index_state}. "
            "Index builds may take a short time to become queryable."
        )
        print("Existing records were left unchanged.")
    finally:
        repository.close()


if __name__ == "__main__":
    asyncio.run(seed())
