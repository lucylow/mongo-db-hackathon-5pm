"""ContextPilot Retail FastAPI service."""
